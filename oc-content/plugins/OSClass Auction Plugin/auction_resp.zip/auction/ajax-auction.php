<?php

$userOffer    = Params::getParam('auction');
$userId       = Params::getParam('user_id');
$sellerId     = Params::getParam('seller_id');
$itemId       = Params::getParam('item_id');
$bName		  = Params::getParam('name');
$bEmail		  = Params::getParam('eMail');
$auctionType    = Params::getParam('auctionType');
$tradeText	  = Params::getParam('auction_text');
$bid_more	  = Params::getParam('bid_more');
$current_price	  = Params::getParam('current_price');
$tradeText = osc_esc_html($tradeText);
$tradeCount = strlen($tradeText);
if($tradeCount > 255){
	$tradeText = substr($tradeText, 0, 255);
}

/*if( !is_null($userOffer) ) {
	$price = str_replace(osc_locale_thousands_sep(), '', trim($userOffer));
	$price = str_replace(osc_locale_dec_point(), '.', $price);
	$userOffer = $price*1000000;
}*/

if($auctionType == '') {
   $auctionType = 1;
}

$item_idA = Item::newInstance()->findByPrimaryKey($itemId);


$message = '';
if (osc_is_web_user_logged_in()){

	@$locked = ModelOffer::newInstance()->getLockedStatus($sellerId, 'user_id', $userId);
	if(@$locked['locked'] != 0){
	  $reason = ModelOffer::newInstance()->getReason($locked['readon_code']);
    }
	if(osc_auction_locking() == 0){
	   $locked['locked'] = 0;
	}
	//$locked['locked'] = 1; debugging only
	if(@$locked['locked'] != 1) {


if ($userId != $sellerId){
	$success = True;

	if(is_numeric($userOffer) || $auctionType == 2){
			//checks for an accepted item and not deleted
    		$auctionAccepted = ModelOffer::newInstance()->getOffer('item_id', $itemId, 'auction_status', 1, 1, 'id', 'DESC', NULL);
    		if (!$auctionAccepted) {
    			$auctionCheck = ModelOffer::newInstance()->getOffer('user_id', osc_logged_user_id(), 'item_id', $itemId, 1, 'id', 'DESC', NULL);
    			$auctionPriceCheck = ModelOffer::newInstance()->getOffer('user_id', osc_logged_user_id(), 'item_id', $itemId, 1, 'auction_value', 'DESC', NULL);
    			//checks if user has already submitted an auction
    			/*if(!$auctionCheck){
    				if($auctionCheck['auction_status'] == 2){
    					$message = __('Please wait until seller accepts or declines your last Bid','auction');
    				} else{*/
    						//$price = osc_format_price($priceCheck['auction_value']);
    						//$price = $price + 10;
//echo $bid_more;
if($bid_more == '')
{
   $bid_more = $current_price + 10;
}
//echo $bid_more;
    					if($auctionType == 1 && $userOffer < $bid_more){
    						$message = __('Please submit an Bid greater or equal ','auction') . $bid_more. ' ' . $item_idA['fk_c_currency_code'];
$success = false;
    					} else{
if( !is_null($userOffer) ) {
	$price = str_replace(osc_locale_thousands_sep(), '', trim($userOffer));
	$price = str_replace(osc_locale_dec_point(), '.', $price);
	$userOffer = $price*1000000;
}
    						//adds auction to item from user
                				ModelOffer::newInstance()->insertOffer(osc_logged_user_id(), NULL, NULL, $sellerId, $itemId, $userOffer, '2', $auctionType, 1, $tradeText);
								if(osc_auction_email_temps()){
									auction_button_send_email($item_idA, $userOffer);
								}
                				$message = __('Your new bid has been submitted' ,'auction');

    					}// ends else for $auctionCheck status == 3
    				//}//ends else for $auctionCheck status == 2

		}else{
			$message = __('Sorry this seller is not currently taking Bids.', 'auction');
		}
	}
	else{
		$message = __('Please enter numbers only', 'auction');
		$success = False;
	}
}
else {
$success = True;
$message = __('You cannot place bid to your item', 'auction');
}
} else{
   //reason for locking user.
   $success = True;
   $message = __('You are blocked', 'auction') . ' ' . @$reason['reason'];
}
} else if(osc_auction_usersOnly() == 0) {

	@$locked = ModelOffer::newInstance()->getLockedStatus($sellerId, 'email', $bEmail);
	if(@$locked['locked'] != 0){
	  $reason = ModelOffer::newInstance()->getReason($locked['readon_code']);
   }

	if(osc_auction_locking() == 0){
	   $locked['locked'] = 0;
	}
	//$locked['locked'] = 1;
	if(@$locked['locked'] != 1) {

if ($userId != $sellerId){
	$success = True;

	if(is_numeric($userOffer) || $auctionType == 2){
	if($bName != '') {
	if($bEmail != '') {
	if (filter_var($bEmail, FILTER_VALIDATE_EMAIL)) {
			//checks for an accepted item
    		$auctionAccepted = ModelOffer::newInstance()->getOffer('item_id', $itemId, 'auction_status', 1, 1, 'id', 'DESC', NULL);
    		if (!$auctionAccepted) {
    			$auctionCheck = ModelOffer::newInstance()->getOffer('b_email', $bEmail, 'item_id', $itemId, 1, 'id', 'DESC', NULL);
    			$auctionPriceCheck = ModelOffer::newInstance()->getOffer('b_email', $bEmail, 'item_id', $itemId, 1, 'auction_value', 'DESC', NULL);
    			//checks if user has already submitted an auction
    			if(!$auctionCheck){
    				/*if($auctionCheck['auction_status'] == 2){
    					$message = __('Please wait until seller accepts or declines your last Bid','auction');
    				} else{*/
    					if($auctionType  == 1 && $userOffer <= $auctionPriceCheck['auction_value']) {
    						$message = __('Please submit an auction greater than','auction') . ' ' . osc_format_price($auctionPriceCheck['auction_value']) . ' ' . $item_idA['fk_c_currency_code'];
    					} else{
    						//adds auction to item from user
                				ModelOffer::newInstance()->insertOffer(NULL, $bEmail, $bName, $sellerId, $itemId, $userOffer, '2', $auctionType, 1, $tradeText);
								if(osc_auction_email_temps()){
									auction_button_send_email($item_idA, $userOffer);
								}
                				$message = __('Your new Bid has been submitted' ,'auction');

    					}// ends else for $auctionCheck status == 3
    				//}//ends else for $auctionCheck status == 2
    			}// ends if ($auctionCheck)
    			else{
    				//adds auction to item from user
                		ModelOffer::newInstance()->insertOffer(NULL, $bEmail, $bName, $sellerId, $itemId, $userOffer, '2', $auctionType, 1, $tradeText);

                		if(osc_auction_email_temps()){
                		   auction_button_send_email($item_idA, $userOffer);
                		}

                		$message = __('Your gdfgfdgfdgfdgfdgfdgfdgfdgfdgfdgfdg Bid has been submitted','auction');
    			}

		}else{
			$message = __('Sorry this seller is not currently taking bids.', 'auction');
		}
	}
	else{
		$message = __('Please enter a valid Email', 'auction');
		$success = False;
	}
	}
	else{
		$message = __('Please enter your email', 'auction');
		$success = False;
	}
	}
	else{
		$message = __('Please enter your name', 'auction');
		$success = False;
	}
	}
	else{
		$message = __('Please enter numbers only', 'auction');
		$success = False;
	}
}
else {
$success = False;
$message = __('You cannot place bid to your item!', 'auction');
}
} else{
   //reason for locking user.
   $success = False;
   $message = __('You are blocked ', 'auction') . @$reason['reason'];
}
}
//$message = __('Your auction of $' . $userOffer . ' has been submitted' . $userId . $sellerId . $itemId ,'auction');
$json = array(
            'success' => $success,
            'message' => $message

        );

echo json_encode($json);
?>