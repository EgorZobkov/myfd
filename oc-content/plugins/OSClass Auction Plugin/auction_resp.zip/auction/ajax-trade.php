<?php
	//ajax-trade.php

	//get url parameters.
	$auctionId = Params::getParam('id');

	if (osc_is_web_user_logged_in()){
		$userOffer = ModelOffer::newInstance()->getOffer('id', $auctionId);

		$item = Item::newInstance()->findByPrimaryKey($userOffer['item_id']);

		if($userOffer['user_id'] !=''){
			$user = User::newInstance()->findByPrimaryKey($userOffer['user_id']);
			$user['r_name'] = $user['s_name'];
			$userName = $user['s_name'];
			if(OSCLASS_VERSION >= '2.3'){
				if(OSCLASS_VERSION >= '3.1' && $user['s_username'] != $user['pk_i_id']){
					$user['s_name'] =  '<a title="'. __("View ","auction"). ucfirst($user['s_username']) . __("'s profile", "auction") . '" href="'. osc_base_url(true) .'?page=user&action=pub_profile&id='. $userOffer['user_id'] .'" >'. $user['s_username'] . '</a>';
					$userName = '';
				} else {
					$user['s_name'] =  '<a title="'. __("View ","auction"). ucfirst($user['s_name']) . __("'s profile", "auction") . '" href="'. osc_base_url(true) .'?page=user&action=pub_profile&id='. $userOffer['user_id'] .'" >'. $user['s_name'] . '</a>';
					$userName = '';
				}
			}
		} else{
			$user['s_name'] = $userOffer['b_name'] . ' *';
			$user['s_email'] = $userOffer['b_email'];
			$user['pk_i_id'] = '';
			$userName = $userOffer['b_email'];
		}

		echo '<h1>' . __('Trade Details for listing','auction') . ' "' . $item['s_title'] . '"</h1>';
		echo '<hr />';
		echo '<br />';
		echo __('Offer made by:', 'auction') . ' ' . $user['s_name'] . '<br />';
		if($userOffer['auction_type'] == 3) {
			echo __('Offer','auction') . osc_format_price($userOffer['auction_value']) . '<br />';
		}
		echo __('Trade','auction') . '<br />';
		echo '<div class="tradeTextA">' . nl2br($userOffer['trade_text']) . '</div>';
	}
?>
