<?php
    /*
     *      OSCLass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2010 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    /**
     * Model database for Offer Button tables
     *
     * @package OSClass
     * @subpackage Model
     * @1.0
     */
    class ModelOffer extends DAO {
        /**
         * It references to self object: ModelOffer.
         * It is used as a singleton
         *
         * @access private
         * @1.0
         * @var ModelOffer
         */
        private static $instance ;

        /**
         * It creates a new ModelOffer object class if it has been created
         * before, it return the previous object
         *
         * @access public
         * @1.0
         * @return ModelOffer
         */
        public static function newInstance() {
            if( !self::$instance instanceof self ) {
                self::$instance = new self ;
            }
            return self::$instance ;
        }

        /**
         * Construct
         */
        function __construct() {
            parent::__construct();
        }

        /**
         * Return table name auction_button
         * @return string
         */
        public function getTable_auction_button() {
            return DB_TABLE_PREFIX.'t_auction_button';
        }

        /**
         * Return table name auction_item_options
         * @return string
         */
        public function getTable_auction_item() {
            return DB_TABLE_PREFIX.'t_auction_item_options';
        }

        /**
         * Return table name auction_item_options
         * @return string
         */
        public function getTable_auction_opt() {
            return DB_TABLE_PREFIX.'t_auction_options';
        }

        /**
         * Return table name auction_reason
         * @return string
         */
        public function getTable_auction_reason() {
            return DB_TABLE_PREFIX.'t_auction_reason';
        }

        /**
         * Return table name auction_user_locked
         * @return string
         */
        public function getTable_auction_user_locked() {
            return DB_TABLE_PREFIX.'t_auction_user_locked';
        }

        /**
         * Return table name t_users
         * @return string
         */
        public function getTable_users() {
            return DB_TABLE_PREFIX.'t_user';
        }

        /**
         * Import sql file
         * @param type $file
         */
        public function import($file) {
            $path = osc_plugin_resource($file) ;
            $sql = file_get_contents($path);

           if(! $this->dao->importSQL($sql) ){
                throw new Exception( "Error importSQL::ModelOffer<br>".$file ) ;
            }
        }

        /**
         * Remove data and tables related to the plugin.
         */
        public function uninstall() {
            $this->dao->query(sprintf('DROP TABLE %s', $this->getTable_auction_reason()) ) ;
            $this->dao->query(sprintf('DROP TABLE %s', $this->getTable_auction_user_locked()) ) ;
            $this->dao->query(sprintf('DROP TABLE %s', $this->getTable_auction_item()) ) ;
            $this->dao->query(sprintf('DROP TABLE %s', $this->getTable_auction_opt()) ) ;
            $this->dao->query(sprintf('DROP TABLE %s', $this->getTable_auction_button()) ) ;
        }

        /**
         * Adds email templstes.
         *
         *
         */
        public function insertEmailTemplates() {
            //used for email template
            $this->dao->insert(DB_TABLE_PREFIX.'t_pages', array('s_internal_name' => 'email_new_auction', 'b_indelible' => 1, 'dt_pub_date' => date('Ydm')));
            $this->dao->insert(DB_TABLE_PREFIX.'t_pages', array('s_internal_name' => 'email_auction_status', 'b_indelible' => 1, 'dt_pub_date' => date('Ydm')));

            $this->dao->select();
            $this->dao->from( DB_TABLE_PREFIX.'t_pages' );
            $this->dao->where('s_internal_name', 'email_new_auction');

            $result = $this->dao->get();
            $pageInfo = $result->row();

            $this->dao->select();
            $this->dao->from( DB_TABLE_PREFIX.'t_pages' );
            $this->dao->where('s_internal_name', 'email_auction_status');

            $result = $this->dao->get();
            $pageInfo1 = $result->row();

            foreach(osc_listLanguageCodes() as $locales) {
               $this->dao->insert(DB_TABLE_PREFIX.'t_pages_description', array('fk_i_pages_id' => $pageInfo['pk_i_id'], 'fk_c_locale_code' => $locales, 's_title' => '{WEB_TITLE} - New auction on: {ITEM_TITLE}', 's_text' => "<p>Hi {CONTACT_NAME}!</p>\r\n<p> </p>\r\n<p>You just got a new auction of \${OFFER_VALUE} on your item {ITEM_TITLE} on {WEB_TITLE}.</p>\r\n<p>Click on the link to view the new auction {OFFER_URL}</p><p> </p>\r\n<p>This is an automatic email, if you have already seen this auction, please ignore this email.</p>\r\n<p> </p>\r\n<p>Thanks</p>"));
               $this->dao->insert(DB_TABLE_PREFIX.'t_pages_description', array('fk_i_pages_id' => $pageInfo1['pk_i_id'], 'fk_c_locale_code' => $locales, 's_title' => '{WEB_TITLE} - Offer status updated on: {ITEM_TITLE}', 's_text' => "<p>Hi {CONTACT_NAME}!</p>\r\n<p> </p>\r\n<p>Your auction on {ITEM_TITLE} {OFFER_STATUS} on {WEB_TITLE}.</p>\r\n<p>Click on the link to view the staus of your auction {OFFER_STATUS_URL}</p><p> </p>\r\n<p>This is an automatic email, if you have already seen this auction, please ignore this email.</p>\r\n<p> </p>\r\n<p>Thanks</p>"));
            }
        }

        /**
         * Remove Email Templates
         *
         *
         */ 
        public function removeEmailTemplates() {
            $this->dao->select();
            $this->dao->from( DB_TABLE_PREFIX.'t_pages' );
            $this->dao->where('s_internal_name', 'email_new_auction');

            $result = $this->dao->get();
            $pageInfo = $result->row();

            $this->dao->select();
            $this->dao->from( DB_TABLE_PREFIX.'t_pages' );
            $this->dao->where('s_internal_name', 'email_auction_status');

            $result = $this->dao->get();
            $pageInfo1 = $result->row();

            $this->dao->delete( DB_TABLE_PREFIX.'t_pages_description', array('fk_i_pages_id' => $pageInfo['pk_i_id']));
            $this->dao->delete( DB_TABLE_PREFIX.'t_pages_description', array('fk_i_pages_id' => $pageInfo1['pk_i_id']));
            $this->dao->delete( DB_TABLE_PREFIX.'t_pages', array('pk_i_id' => $pageInfo['pk_i_id']));
            $this->dao->delete( DB_TABLE_PREFIX.'t_pages', array('pk_i_id' => $pageInfo1['pk_i_id']));
        }

        /**
         * Get users
         *
         * @return array
         */
        public function getUsers() {
            $this->dao->select();
            $this->dao->from( $this->getTable_users());
            $this->dao->where('b_enabled', 1);
            $this->dao->where('b_active', 1);

            $result = $this->dao->get();
            if($result != null) {
				return $result->result();
			} else{
				return array();
			}
        }

        /**
         * Get auctions
         *
         * @param int $where, $del, $limit
         * @param string $whereKey, $orderBy, $oDir
         * @return array
         */
        public function getOffers($whereKey, $where, $whereKey1=NULL, $where1=NULL, $del=NULL, $orderBy = null, $oDir = null, $limit = 1) {
            $this->dao->select();
            $this->dao->from( $this->getTable_auction_button());

            if(!$whereKey == NULL && !$where == NULL) {
				$this->dao->where($whereKey, $where);
			}

            if(!$whereKey1 == NULL && !$where1 == NULL) {
               $this->dao->where($whereKey1, $where1);
            }

            if($del == 1) {
               $this->dao->where('sDelete', 0);
            }

            if(!$orderBy == NULL && !$oDir == NULL) {
               $this->dao->orderBy($orderBy, $oDir);
            }

            if(!$limit == NULL) {
               $this->dao->limit($limit);
            }

            $result = $this->dao->get();
            if($result != null) {
				return $result->result();
			} else {
				return array();
			}
        }

        /**
         * Get auction
         *
         * @param int $where, $del, $limit
         * @param string $whereKey, $orderBy, $oDir
         * @return array
         */
        public function getOffer($whereKey, $where, $whereKey1 =NULL, $where1=NULL, $del=NULL, $orderBy = null, $oDir = null, $limit = 3) {
            $this->dao->select();
            $this->dao->from( $this->getTable_auction_button());
            $this->dao->where($whereKey, $where);

            if(!$whereKey1 == NULL && !$where1 == NULL) {
               $this->dao->where($whereKey1, $where1);
            }

            if($del == 1) {
               $this->dao->where('sDelete', 0);
            }

            if(!$orderBy == NULL && !$oDir == NULL) {
               $this->dao->orderBy($orderBy, $oDir);
            }

            if(!$limit == NULL) {
               $this->dao->limit($limit);
            }

            $result = $this->dao->get();
            if($result != null) {
               return $result->row();
            } else {
               return false;
            }
        }

        /**
         * Get auction item options
         *
         * @param int $itemId
         * @return array
         */
        public function getOfferItemOption($itemId) {
            $this->dao->select();
            $this->dao->from( $this->getTable_auction_item());
            $this->dao->where('fk_i_item_id', $itemId);

            $result = $this->dao->get();
            if($result != null) {
				return $result->row();
			} else {
				return array();
			}
        }

        /**
         * Insert auction item options
         *
         * @param int $itemId, $bOffer, $bMonetary, $bTrade
         */
        public function insertOptions( $itemId, $bOffer = 0, $bMonetary = 0, $bTrade = 0)
        {
            $this->dao->insert($this->getTable_auction_item(), array('fk_i_item_id' => $itemId, 'b_auctionYes' => $bOffer, 'b_auctionMonetary' => $bMonetary, 'b_auctionTrade' => $bTrade)) ;
        }

        /**
         * Replace auction item options
         *
         * @param int $itemId, $bOffer, $bMonetary, $bTrade
         */
        public function replaceOptions( $itemId, $bOffer = 0, $bMonetary = 0, $bTrade = 0) {
				$this->dao->replace($this->getTable_auction_item(), array('fk_i_item_id' => $itemId, 'b_auctionYes' => $bOffer, 'b_auctionMonetary' => $bMonetary, 'b_auctionTrade' => $bTrade)) ;
        }

        /**
         * Delete auction button and auction item options if the item gets deleted
         *
         *
         */
        public function deleteOfferItem($itemId) {
            $this->dao->delete( $this->getTable_auction_item(), array('fk_i_item_id' => $itemId));
            $this->dao->delete( $this->getTable_auction_button(), array('item_id' => $itemId));
        }

        /**
         * Update auction_button
         *
         * @param int $sellerId
         */
        public function updateOfferNew($sellerId) {
            $this->_update( $this->getTable_auction_button(), array('oNew' => 0), array('seller_id' => $sellerId, 'oNew' => 1)) ;
        }

        /**
         * Get auction user locked
         *
         * @param int $sellerId, $userId
         * @return array
         */
        public function getLockedStatus($sellerId, $whereKey = NULL, $where = NULL) {
            $this->dao->select();
            $this->dao->from( $this->getTable_auction_user_locked());
            $this->dao->where('seller_id', $sellerId);
            if($whereKey != NULL) {
               $this->dao->where($whereKey, $where);
            }

            $result = $this->dao->get();
            if($result) {
               return $result->row();
            } else {
               return 0;
            }
        }

        /**
         * Get auction user reason
         *
         * @param int $Id
         * @return array
         */
        public function getReason($Id) {
            $this->dao->select();
            $this->dao->from( $this->getTable_auction_reason());
            $this->dao->where('seller_id', $Id);

            $result = $this->dao->get();
            if($result) {
				return $result->row();
			} else {
				return array();
			}
        }

        /**
         * Get auction reasons
         *
         * @param int $Id
         * @return array
         */
        public function getReasons() {
            $this->dao->select();
            $this->dao->from( $this->getTable_auction_reason());

            $result = $this->dao->get();
            return $result->result();
        }

        /**
         * Insert auction
         *
         * @param int $itemId, $bOffer, $bMonetary, $bTrade
         */
        public function insertOffer( $userId, $b_email=NULL, $b_name=NULL, $sellerId, $itemId, $auctionValue, $auctionStatus, $auctionType, $new, $tradeT = null) {
            $this->dao->insert($this->getTable_auction_button(), array('user_id' => $userId, 'b_name' => $b_name, 'b_email' => $b_email, 'seller_id' => $sellerId, 'item_id' => $itemId, 'auction_value' => $auctionValue, 'auction_status' => $auctionStatus,'auction_type' => $auctionType, 'trade_text'=> $tradeT, 'oNew' => $new)) ;
        }

        /**
         * Update auction status
         *
         * @param int $auctionId, $status
         */
        public function updateOfferStatus($status, $auctionId) {
            $this->_update( $this->getTable_auction_button(), array('auction_status' => $status), array('id' => $auctionId)) ;
        }

        /**
         * Update auction price to 2.0
         *
         * @param int $auctionId, $status
         */
        public function updateOfferPrice($price, $auctionId) {
            $this->_update( $this->getTable_auction_button(), array('auction_value' => $price), array('id' => $auctionId)) ;
        }

        /**
         * Update auction deleted
         *
         * @param int $auctionId
         */
        public function updateDelete($auctionId) {
            $this->_update( $this->getTable_auction_button(), array('sDelete' => 1), array('id' => $auctionId)) ;
        }

        /**
         * Update auction locking
         *
         * @param int $auctionId
         */
        public function updateLocking($lock, $whereKey, $where) {
            $this->_update( $this->getTable_auction_button(), array('user_locked' => $lock), array($whereKey => $where)) ;
        }

        /**
         * replace user locked
         *
         * @param $sellerId, $key, $keyValue, $reason, $locked
         */
        public function replaceLocked($sellerId, $key, $keyValue, $reason, $locked) {
			$this->dao->select();
            $this->dao->from( $this->getTable_auction_user_locked());
            $this->dao->where($key, $keyValue);
            $this->dao->where('seller_id', $sellerId);

            $result = $this->dao->get();
            if($result){
				$data = $result->row();
				if($key != 'email' && !is_null($data['user_id'])){
					$this->_update($this->getTable_auction_user_locked(), array('seller_id' => $sellerId, $key => $keyValue, 'reason_code' => $reason, 'locked' => $locked), array('seller_id' => $sellerId, 'user_id' => $keyValue));
				} elseif(!is_null($data['email'])) {
					$this->_update($this->getTable_auction_user_locked(), array('seller_id' => $sellerId, $key => $keyValue, 'reason_code' => $reason, 'locked' => $locked), array('seller_id' => $sellerId, 'email' => $keyValue));
				} else{
					$this->dao->replace( $this->getTable_auction_user_locked(), array('seller_id' => $sellerId, $key => $keyValue, 'reason_code' => $reason, 'locked' => $locked));
				}
			} else{
				$this->dao->replace( $this->getTable_auction_user_locked(), array('seller_id' => $sellerId, $key => $keyValue, 'reason_code' => $reason, 'locked' => $locked));
			}
        }

        /**
         * Update auction reasons
         *
         * @param $reason, $auctionId
         */
        public function updateReason($reason, $auctionId) {
            $this->_update( $this->getTable_auction_reason(), array('reason' => $reason), array('id' => $auctionId)) ;
        }

        /**
         * Insert auction reason
         *
         * @param $reason
         */
        public function insertReason($reason) {
            $this->dao->insert( $this->getTable_auction_reason(), array('reason' => $reason)) ;
        }

        /**
         * Delete auction reason
         *
         * @param $auctionId
         */
        public function deleteReason($auctionId) {
            $this->dao->delete( $this->getTable_auction_reason(), array('id' => $auctionId)) ;
        }

        // update
        function _update($table, $values, $where) {
            $this->dao->from($table) ;
            $this->dao->set($values) ;
            $this->dao->where($where) ;
            return $this->dao->update() ;
        }
    }
?>