<?php //if(osc_is_web_user_logged_in() ) {

   // $i_userId = osc_logged_user_id();
    $itemsPerPage = (Params::getParam('itemsPerPage') != '') ? Params::getParam('itemsPerPage') : 5;

$url = $_SERVER['REQUEST_URI']; //you will get last part of url from there
$parts = explode('&', $url, 5);
//print_r($parts);
$id = $parts[2];

    $iPage        = (Params::getParam('iPage') != '') ? Params::getParam('iPage') : 0;
    if($iPage != 0) {
		$iPage--;
	}
	 $search = new Search();
    $search->addConditions(sprintf("%st_auction_button.item_id= %d", DB_TABLE_PREFIX, $id));
    $search->addConditions(sprintf("%st_auction_button.item_id = %st_item.pk_i_id AND %st_auction_button.sDelete != 1 GROUP BY item_id", DB_TABLE_PREFIX, DB_TABLE_PREFIX, DB_TABLE_PREFIX));
    $search->addTable(sprintf("%st_auction_button", DB_TABLE_PREFIX));
    $search->page($iPage, $itemsPerPage);

    $aItems      = $search->doSearch();
    $iTotalItems = $search->count();
    $iNumPages   = ceil($iTotalItems / $itemsPerPage) ;

    View::newInstance()->_exportVariableToView('items', $aItems);
    View::newInstance()->_exportVariableToView('search_total_pages', $iNumPages);
    View::newInstance()->_exportVariableToView('search_page', $iPage) ;

    //Check to see if user flagging plugin installed
    $plugE = Plugins::listEnabled();
    $uFlag = array_search('user_flag/index.php',Plugins::listEnabled());
    if($uFlag !='') {
    	$flag_enabled = 1;
    } else{
    	$flag_enabled = 0;
    }

?>

<div class="content user_account">
    <h1>
        <strong><?php _e('View Bids', 'auction'); ?></strong>
    </h1>
   <!--  <div id="sidebar">
        <?php //echo osc_private_user_menu(); ?>
    </div>
 -->    <div id="main">
                    <!-- <h2><?php _e('Bids on Your Items', 'auction'); ?></h2> -->
                    <?php //osc_reset_items(); ?>
                    <?php if(osc_count_items() == 0) { ?>
                        <h3><?php _e('No Bid yet', 'auction'); ?></h3>
                    <?php } else { ?>
                        <?php while(osc_has_items()) { ?>
                                <div class="item" >
                                        <h3>
                                            <a name="item<?php echo osc_item_id();?>"></a>
                                            <a class="external" href="<?php echo osc_item_url(); ?>" target="_blank"><?php echo osc_item_title(); ?></a>
                                            <?php $itemTitle = osc_item_title(); ?>
                                        </h3>
                                        <p>
                                        <?php if( osc_price_enabled_at_items() ) { _e('Price', 'modern') ; ?>: <?php echo osc_format_price(osc_item_price()); } ?>
                                        <br />
                                        <br />
                                        <?php
                                        $auctions = ModelOffer::newInstance()->getOffers('item_id', osc_item_id(), NULL, NULL, 1, 'id', 'DESC', NULL);
                                        ?>

                                        <div class="dataTables_wrapper">
                                        <table cellpadding="0" cellspacing="0" border="0" class="display" id="datatables_list">
                                        	<thead>
                                        	<tr>
                                        		<?php /*<th>ID</th>*/ ?>
                                                <th><?php _e('User Name:','auction'); ?></th>
                                        		<th><?php _e('Bid','auction'); ?></th>
                                        		<th><?php _e('Status','auction'); ?></th>
                                        		<th><?php _e('Bid Date','auction'); ?></th>
                                        	</tr>
                                        	</thead>
                                        	<tbody>
                                        	<?php
                                        	$auction_accept = 0;
                                        	foreach($auctions as $auction) {
                                        		if ($auction['auction_status'] ==1){
                                        			$auction_accept = 1;
                                        		}
                                        	}

                                        	$odd = 1;
                                        	foreach($auctions as $userAuction){
                                        		 if($odd==1) {
                                        			$odd_even = "odd";
                                        			$odd = 0;
                                    			 } else {
                                        			$odd_even = "even";
                                        			$odd = 1;
                                    			 }

                                        	?>

                                        	<tr class="<?php echo $odd_even;?><?php if($userAuction['user_locked'] == 1){echo ' gray'; }?>">
                                        	<?php
	                                       if($userAuction['user_id'] !=''){
                                        		$user = User::newInstance()->findByPrimaryKey($userAuction['user_id']);
                                        		$user['r_name'] = $user['s_name'];
                                        		$userName = $user['s_name'];
                                        		if(OSCLASS_VERSION >= '2.3'){
													if(OSCLASS_VERSION >= '3.1' && $user['s_username'] != $user['pk_i_id']){
														$user['s_name'] =  '<a title="'. __("View ","auction"). ucfirst($user['s_username']) . __("'s profile", "auction") . '">'. $user['s_username'] . '</a>';
														$userName = '';
													} else {
														$user['s_name'] =  '<a title="'. __("View ","auction"). ucfirst($user['s_name']) . __("'s profile", "auction") . '" >'. $user['s_name'] . '</a>';
														$userName = '';
													}
                                        		}
                                        	} else{
                                        		$user['s_name'] = $userAuction['b_name'] . ' *';
                                        		$user['s_email'] = $userAuction['b_email'];
                                        		$user['pk_i_id'] = '';
                                        		$userName = $userAuction['b_email'];
                                        	}
                                        	?>

                                        		<?php /*<td><?php echo $userAuction['id'];?> </td> */ ?><td><?php echo substr($user['s_name'],39,3).'xxx'; ?><div></td>
                                        		<td><?php if($userAuction['auction_type'] == 1) { echo osc_format_price($userAuction['auction_value']);}else if($userAuction['auction_type'] == 2){ echo '<a class="trades fancybox.ajax" href="' . osc_ajax_plugin_url('auction/ajax-trade.php') . '&id=' . $userAuction['id'] . '">' . __('Trade','auction') . '</a>';}else if($userAuction['auction_type'] == 3) { echo osc_format_price($userAuction['auction_value']) . ' + <a class="trades fancybox.ajax" href="' . osc_ajax_plugin_url('auction/ajax-trade.php') . '&id=' . $userAuction['id'] . '">' . __('Trade','auction') . '</a>';} ?></td>
                                        		<td><?php 
if(auction_status($userAuction['auction_status']) == 'Accepted') 
  { echo '<strong>'.auction_status($userAuction['auction_status']).'<strong>'; }
else{ echo auction_status($userAuction['auction_status']); }
  ?></td>
                                        		<td><?php echo osc_format_date($userAuction['auction_date']) . ' ' . osc_format_date($userAuction['auction_date'], 'g:i A') ; ?></td>
                                        	</tr>
                                        	<?php if(OB_DEBUG){ ?>
                                        	<tr>
												<td colspan="4">
													userAuction array
													<?php
													 echo '<pre>';
	                                    			 print_r($userAuction);
	                                    			 echo '</pre>';
	                                    			?>
												</td>
                                        	</tr>
                                        	<?php } ?>
                                        	<?php }
                                        	$auction_accept = 0; ?>
                                        	</tbody>
                                        </table>
                                        <?php if (osc_auction_usersOnly() == 0){echo '* ' . __('Non registered user.','auction');} ?>
                                        </div>
                                        </p>
                                </div>
                        <?php } ?>
                        <br />
                        <div class="paginate">
            <?php echo osc_pagination(array('url' => osc_render_file_url(osc_plugin_folder(__FILE__) . 'auction_byItem.php') . '?iPage={PAGE}')); ?>
        </div>
                    <?php } ?>
                </div>
</div>
