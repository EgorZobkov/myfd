ALTER TABLE oc_t_item MODIFY f_price float NULL;
