<?php if(osc_is_web_user_logged_in() ) {
    $i_userId = osc_logged_user_id();
    $itemsPerPage = (Params::getParam('itemsPerPage') != '') ? Params::getParam('itemsPerPage') : 5;
    $iPage        = (Params::getParam('iPage') != '') ? Params::getParam('iPage') : 0;
    if($iPage != 0) {
		$iPage--;
	}
	 $search = new Search();
    $search->addConditions(sprintf("%st_auction_button.user_id = %d ", DB_TABLE_PREFIX, $i_userId));
    $search->addConditions(sprintf("%st_auction_button.item_id = %st_item.pk_i_id AND %st_auction_button.sDelete != 1 GROUP BY item_id", DB_TABLE_PREFIX, DB_TABLE_PREFIX, DB_TABLE_PREFIX));
    $search->addTable(sprintf("%st_auction_button", DB_TABLE_PREFIX));
    $search->page($iPage, $itemsPerPage);

    $aItems      = $search->doSearch();
    $iTotalItems = $search->count();
    $iNumPages   = ceil($iTotalItems / $itemsPerPage) ;

    View::newInstance()->_exportVariableToView('items', $aItems);
    View::newInstance()->_exportVariableToView('search_total_pages', $iNumPages);
    View::newInstance()->_exportVariableToView('search_page', $iPage) ;
?>

<div class="content user_account">
    <h1>
        <strong><?php _e('View Your Submitted Bids', 'auction'); ?></strong>
    </h1>
    <div id="sidebar">
        <?php echo osc_private_user_menu(); ?>
    </div>
    <div id="main">
                    <h2><?php _e('Your Bids', 'auction'); ?></h2>
                    <?php //osc_reset_items(); ?>
                    <?php if(osc_count_items() == 0) { ?>
                        <h3><?php _e('You have not placed any auctions yet', 'auction'); ?></h3>
                    <?php } else { ?>
                        <?php while(osc_has_items()) { ?>
                                <div class="item" >
                                        <h3>
                                            <a name="item<?php echo osc_item_id();?>"></a>
                                            <a class="external" href="<?php echo osc_item_url(); ?>" target="_blank"><?php echo osc_item_title(); ?></a>
                                        </h3>
                                        <p>
                                        <?php if( osc_price_enabled_at_items() ) { _e('Price', 'modern') ; ?>: <?php echo osc_format_price(osc_item_price()); } ?>
                                        <br />
                                        <br />
                                        <?php
                                        $auctions = ModelOffer::newInstance()->getOffers('item_id', osc_item_id(), 'user_id', osc_logged_user_id(), 1, 'id', 'DESC', NULL);

                                        ?>
                                        <div class="dataTables_wrapper">
                                        <table cellpadding="0" cellspacing="0" border="0" class="display" id="datatables_list">
                                        	<thead>
                                        	<tr>
                                        		<th><?php _e('Bid','auction'); ?></th>
                                        		<th><?php _e('status','auction'); ?></th>
                                        		<th><?php _e('Bid Date','auction'); ?></th>
                                        	</tr>
                                        	</thead>
                                        	<tbody>
                                        	<?php
                                        	$odd = 1;
                                        	foreach($auctions as $userOffer){
                                        		 if($odd==1) {
                                        			$odd_even = "odd";
                                        			$odd = 0;
                                    			 } else {
                                        			$odd_even = "even";
                                        			$odd = 1;
                                    			 }
                                    			 $locked = ModelOffer::newInstance()->getLockedStatus($userOffer['seller_id'], 'user_id', osc_logged_user_id());
	                                           if(@$locked['locked'] != 0){
	                                               $reason = ModelOffer::newInstance()->getReason($locked['readon_code']);
                                              }

                                        	?>
                                        	<tr class="<?php echo $odd_even;?>">
                                        	<?php $user = User::newInstance()->findByPrimaryKey($userOffer['user_id']); ?>
                                        		<td><?php if($userOffer['auction_type'] == 1){ echo osc_format_price($userOffer['auction_value']);}else if($userOffer['auction_type'] == 2){_e('Trade','auction');}else if($userOffer['auction_type'] == 3){echo osc_format_price($userOffer['auction_value']) . __(' Trade', 'auction');} ?></td>
                                        		<td><?php if($userOffer['user_locked'] != 1) { echo auction_status($userOffer['auction_status']);}else{ echo __('You are blocked at this time ','auction') . @$reason['reason']; } ?></td>
                                        		<td><?php echo osc_format_date($userOffer['auction_date']) . ' ' . osc_format_date($userOffer['auction_date'], 'g:i A'); ?><div class="offBut"><?php echo auction_contact($userOffer, osc_item() ); ?></div></td></td>
                                        	</tr>
                                        	<?php } ?>
                                        	</tbody>
                                        </table>
                                        </div>
                                        </p>
                                </div>
                        <?php } ?>
                        <br />
                        <div class="paginate">
            <?php echo osc_pagination(array('url' => osc_render_file_url(osc_plugin_folder(__FILE__) . 'auction_button.php') . '?iPage={PAGE}')); ?>
        </div>
                   <?php } ?>
                </div>
</div>
<?php } else {
// HACK TO DO A REDIRECT ?>
    	<script>location.href="<?php echo osc_user_login_url(); ?>"</script>
<?php } ?>