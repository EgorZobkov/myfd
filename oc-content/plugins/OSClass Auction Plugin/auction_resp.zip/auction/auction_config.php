         
        <style type="text/css">
          body, html {
              height: 100%;
              margin: 0;
              -webkit-font-smoothing: antialiased;
              font-weight: 100;
              background: #aadfeb;
              text-align: center;
              font-family: helvetica;
          }
          
          .tabs input[type=radio] {
              position: absolute;
              top: -9999px;
              left: -9999px;
          }
          .tabs {
            width: 90%;
            float: none;
            list-style: none;
            position: relative;
            padding: 0;
            margin: 0px;
          }
          .tabs li{
            float: left;
          }
          .tabs label {
              display: block;
              padding: 10px 20px;
              border-radius: 2px 2px 0 0;
              color: #08C;
              font-size: 24px;
              font-weight: normal;
              font-family: 'Roboto', helveti;
              background: rgba(255,255,255,0.2);
              cursor: pointer;
              position: relative;
              top: 3px;
              -webkit-transition: all 0.2s ease-in-out;
              -moz-transition: all 0.2s ease-in-out;
              -o-transition: all 0.2s ease-in-out;
              transition: all 0.2s ease-in-out;
          }
          .tabs label:hover {
            background: rgba(255,255,255,0.5);
            top: 0;
          }
          
          [id^=tab]:checked + label {
            background: #08C;
            color: white;
            top: 0;
          }
          
          [id^=tab]:checked ~ [id^=tab-content] {
              display: block;
          }
          .tab-content{
            z-index: 2;
            display: none;
            text-align: left;
            width: 100%;
            font-size: 20px;
            line-height: 120%;
            padding-top: 10px;
            background: #08C;
            padding: 15px;
            color: white;
            position: absolute;
            top: 47px;
            left: 0;
            box-sizing: border-box;
            -webkit-animation-duration: 0.5s;
            -o-animation-duration: 0.5s;
            -moz-animation-duration: 0.5s;
            animation-duration: 0.5s;
          }

          .lebel{
            font-weight: bold;
            color: white!important;
            background: none!important;
            font-size: 16px!important;
            line-height: 0px;
            width: 50%;
            float: left;
          }

          .cat_link{
            text-decoration: none;
            color: white;
          }

          p,h2,h4{
                margin: 1px 0px;
          }

          p{
            font-size: 15px;
          }

          h4{
            font-size: 15px;
          }

        </style>
    </head>
    <body>
        <div class="container">
            <div class="main">
                <ul class="tabs">
                    <li>
                      <input type="radio" name="tabs" id="tab1">
                      <label for="tab1">Category Configuration</label>
                      <div id="tab-content1" class="tab-content animated fadeIn">
                        
                            <fieldset>
                            <legend><?php _e('Configure Plugin Categories','auction'); ?></legend>
                            <br />
                            <a class="cat_link" href="<?php echo osc_admin_base_url(true) . '?page=plugins&action=configure&plugin=auction/index.php'; ?>" ><?php _e('Configure which category this plugin displays in.'); ?></a><br /><br />
                            </fieldset>
                      </div>
                    </li>
                    <li>
                      <input type="radio" checked name="tabs" id="tab2">
                      <label for="tab2">Auction Plugin Configuration</label>
                      <div id="tab-content2" class="tab-content animated fadeIn">

                     
<?php
  
    $enabled            = '';
    $dao_preference = new Preference();
    if(Params::getParam('enabled') != '') {
        $enabled = Params::getParam('enabled');
    } else {
        $enabled = (osc_auction_enabled() != '') ? osc_auction_enabled() : '' ;
    }
    $lastThree            = '';
    $dao_preference = new Preference();
    if(Params::getParam('lastThree') != '') {
        $lastThree = Params::getParam('lastThree');
    } else {
        $lastThree = (osc_auction_lastThree() != '') ? osc_auction_lastThree() : '' ;
    }
    $locking            = '';
    $dao_preference = new Preference();
    if(Params::getParam('locking') != '') {
        $locking = Params::getParam('locking');
    } else {
        $locking = (osc_auction_locking() != '') ? osc_auction_locking() : '' ;
    }
    $days            = '';
    $dao_preference = new Preference();
    if(Params::getParam('auction_days') != '') {
        $days = Params::getParam('auction_days');
    } else {
        $days = (osc_auction_days() != '') ? osc_auction_days() : '' ;
    }
    $emailTemps            = '';
    $dao_preference = new Preference();
    if(Params::getParam('emailTemps') != '') {
        $emailTemps = Params::getParam('emailTemps');
    } else {
        $emailTemps = (osc_auction_email_temps() != '') ? osc_auction_email_temps() : '' ;
    }
    $delOff            = '';
    $dao_preference = new Preference();
    if(Params::getParam('delOff') != '') {
        $delOff = Params::getParam('delOff');
    } else {
        $delOff = (osc_auction_delOff() != '') ? osc_auction_delOff() : '' ;
    }
    $usersOnly            = '';
    $dao_preference = new Preference();
    if(Params::getParam('usersOnly') != '') {
        $usersOnly = Params::getParam('usersOnly');
    } else {
        $usersOnly = (osc_auction_usersOnly() != '') ? osc_auction_usersOnly() : '' ;
    }
    $auctionTrade            = '';
    $dao_preference = new Preference();
    if(Params::getParam('trade') != '') {
        $auctionTrade = Params::getParam('trade');
    } else {
        $auctionTrade = (osc_auction_trade() != '') ? osc_auction_trade() : '' ;
    }
    $auctionText            = '';
    $dao_preference = new Preference();
    if(Params::getParam('oText') != '') {
        $auctionText = Params::getParam('oText');
    } else {
        $auctionText = (osc_auction_text() != '') ? osc_auction_text() : '' ;
    }

    if( Params::getParam('option') == 'stepone' ) {
        $dao_preference->update(array("s_value" => $enabled), array("s_section" => "plugin-auction", "s_name" => "auction_enabled")) ;
        $dao_preference->update(array("s_value" => $lastThree), array("s_section" => "plugin-auction", "s_name" => "auction_lastThree")) ;
        $dao_preference->update(array("s_value" => $locking), array("s_section" => "plugin-auction", "s_name" => "auction_locking")) ;
        $dao_preference->update(array("s_value" => $delOff), array("s_section" => "plugin-auction", "s_name" => "auction_delOff")) ;
        $dao_preference->update(array("s_value" => $days), array("s_section" => "plugin-auction", "s_name" => "auction_days")) ;
        $dao_preference->update(array("s_value" => $emailTemps), array("s_section" => "plugin-auction", "s_name" => "auction_email_temps")) ;
        $dao_preference->update(array("s_value" => $usersOnly), array("s_section" => "plugin-auction", "s_name" => "auction_usersOnly")) ;
        $dao_preference->update(array("s_value" => $auctionTrade), array("s_section" => "plugin-auction", "s_name" => "auction_trade")) ;
        $dao_preference->update(array("s_value" => $auctionText), array("s_section" => "plugin-auction", "s_name" => "auction_text")) ;
        echo '<div style="text-align:center; font-size:22px; background-color:#00bb00;"><p>' . __('Settings Saved', 'auction') . '.</p></div>';
    }
    unset($dao_preference) ;
    $pluginInfo = osc_plugin_get_info('auction/index.php');
    //print_r(osc_plugin_get_info('auction/index.php'));
    //osc_set_preference('days', Params::getParam('days'), 'auction');
?>

<form action="<?php osc_admin_base_url(true); ?>" method="post">
    <input type="hidden" name="page" value="plugins" />
    <input type="hidden" name="action" value="renderplugin" />
    <input type="hidden" name="file" value="auction/auction_config.php" />
    <input type="hidden" name="option" value="stepone" />
    <div>
    <fieldset>
        <fieldset>
        <!-- <legend><?php echo _e('Auction Configuration','auction'); ?></legend> -->
        <label class="lebel" for="enabled" style="font-weight: bold;"><?php _e('Enable Bid button?', 'auction'); ?></label> : 
        <select name="enabled" id="enabled">
            <option <?php if($enabled == 1){echo 'selected="selected"';}?>value='1'><?php _e('Yes','auction'); ?></option>
            <option <?php if($enabled == 0){echo 'selected="selected"';}?>value='0'><?php _e('No','auction'); ?></option>
        </select>
        <br /><!-- 
        <label class="lebel" for="lastThree" style="font-weight: bold;"><?php _e('Display the top three auctions', 'auction'); ?></label> : 
        <select name="lastThree" id="lastThree">
            <option <?php if($lastThree == 1){echo 'selected="selected"';}?>value='1'><?php _e('Yes','auction'); ?></option>
            <option <?php if($lastThree == 0){echo 'selected="selected"';}?>value='0'><?php _e('No','auction'); ?></option>
        </select>
        <br /> -->
        <label class="lebel" for="locking" style="font-weight: bold;"><?php _e('Allow sellers to lock users from making Bids on their items?', 'auction'); ?></label> : 
        <select name="locking" id="locking">
            <option <?php if($locking == 1){echo 'selected="selected"';}?>value='1'><?php _e('Yes','auction'); ?></option>
            <option <?php if($locking == 0){echo 'selected="selected"';}?>value='0'><?php _e('No','auction'); ?></option>
        </select>
        <br />
        <label class="lebel" for="email" style="font-weight: bold;"><?php _e('Enable the sending of the email templates', 'auction'); ?></label> : 
        <select name="emailTemps" id="emailTemps">
            <option <?php if($emailTemps == 1){echo 'selected="selected"';}?>value='1'><?php _e('Yes','auction'); ?></option>
            <option <?php if($emailTemps == 0){echo 'selected="selected"';}?>value='0'><?php _e('No','auction'); ?></option>
        </select>
       
        <br />
        <label class="lebel" for="delOff" style="font-weight: bold;"><?php _e('Allow seller to delete auctions', 'auction'); ?></label> : 
        <select name="delOff" id="delOff">
            <option <?php if($delOff == 1){echo 'selected="selected"';}?>value='1'><?php _e('Yes','auction'); ?></option>
            <option <?php if($delOff == 0){echo 'selected="selected"';}?>value='0'><?php _e('No','auction'); ?></option>
        </select>
        <br />
        <label class="lebel" for="usersOnly" style="font-weight: bold;"><?php _e('Only logged in users can submit auctions', 'auction'); ?></label> : 
        <select name="usersOnly" id="usersOnly">
            <option <?php if($usersOnly == 1){echo 'selected="selected"';}?>value='1'><?php _e('Yes','auction'); ?></option>
            <option <?php if($usersOnly == 0){echo 'selected="selected"';}?>value='0'><?php _e('No','auction'); ?></option>
        </select> 
        <br />
        <label class="lebel" for="days" style="font-weight: bold;"><?php _e('Choose days for auction', 'auction'); ?></label> : 
        <!-- <select name="days" id="days">
            <option <?php if($days == ''){echo 'selected="selected"';}?>value=''><?php _e('Select','auction'); ?></option>
            <option <?php if($days == 7){echo 'selected="selected"';}?>value='7'><?php _e('7 days',''); ?></option>
            <option <?php if($days == 8){echo 'selected="selected"';}?>value='8'><?php _e("8 days",'auction'); ?></option>
            <option <?php if($days == 9){echo 'selected="selected"';}?>value='9'><?php _e('9 days','auction'); ?></option>
            <option <?php if($days == 10){echo 'selected="selected"';}?>value='10'><?php _e('10 days','auction'); ?></option>
        </select> -->
        <input type="text" class="form-control" name="auction_days" value="<?php echo $days; ?>">
        <br />
        <input type="hidden" name="oText" value="2">
        <br />
        <input type="submit" value="<?php _e('Save', 'carousel'); ?>" />
        </fieldset>
     </fieldset>
    </div>
</form>

  
                      </div>
                    </li>
                    <li>
                      <input type="radio" name="tabs" id="tab3">
                      <label for="tab3">Help</label>
                      <div id="tab-content3" class="tab-content animated fadeIn">
                       
                            <div id="settings_form">
                                <div style="padding: 0 10px 10px;">
                                    <div>
                                        <fieldset>
                                            <h4>
                                                <?php _e('What is the Auction Plugin?', 'auction'); ?>
                                            </h4>
                                            <p>
                                                <?php _e('The Auction Plugin creates a new and quicker way for buyers to submit auctions to the seller.', 'auction'); ?>
                                            </p>
                                            <h4>
                                                <?php _e('How does Bid Button plugin work?', 'auction'); ?>
                                            </h4>
                                            <p>
                                                <?php _e('This plugin places a button on items that the user wants to accept auctions on. Then the user can easly submit his/her auction to the seller.', 'auction'); ?>
                                            </p>
                                            <h4>
                                                <?php _e('How do I install the  Bid Button plugin?', 'auction'); ?>
                                            </h4>
                                            <p>
                                                <?php _e('You have to edit your item.php file in your theme folder. Then add the following line &lt;?php auction_button(); ?&gt; anywhere you want the auction button to show up.', 'auction'); ?>
                                            </p>
                                            <h4>
                                                <?php _e('How do I edit the email templates?', 'auction'); ?>
                                            </h4>
                                            <p>
                                                <?php _e('To edit the email templates you have to go under the Email & Alerts menu. Then you will see towards the end of the list two email templates.', 'auction'); ?>
                                            </p>
                                            <h4>
                                                <?php _e('Which email template is for the seller and which is for the buyer?', 'auction'); ?>
                                            </h4>
                                            <p>
                                                <?php _e('The "email_new_auction" template is for the seller and the "email_auction_status" template is for the buyers.', 'auction'); ?>
                                            </p>
                                            <h4>
                                                <?php _e('What are the dynamic tags that can be used in the "email_new_auction" template?', 'auction'); ?>
                                            </h4>
                                            <p>
                                                <?php _e('{ITEM_ID}, {CONTACT_NAME}, {CONTACT_EMAIL}, {WEB_URL}, {ITEM_TITLE}, {ITEM_URL}, {WEB_TITLE}, {OFFER_URL}, {OFFER_VALUE}.', 'auction'); ?>
                                            </p>
                                            <h4>
                                                <?php _e('What are the dynamic tags that can be used in the "email_auction_status" template?', 'auction'); ?>
                                            </h4>
                                            <p>
                                                <?php _e('{ITEM_ID}, {CONTACT_NAME}, {CONTACT_EMAIL}, {WEB_URL}, {ITEM_TITLE}, {ITEM_URL}, {WEB_TITLE}, {SELLER_EMAIL}, {OFFER_STATUS}, {OFFER_STATUS_URL}, {SELLER_PHONE}.', 'auction'); ?>
                                            </p>
                                        </fieldset>
                                    </div>
                                </div>
                            </div>
                      </div>
                    </li>
                </ul>
            </div>
        </div><!-- Container -->


