<?php
/*
Plugin Name: OSClass Auction plugin
Plugin URI: http://osclassplugins.com/
Description: This plugin extends a category of items to display an auction button.
Version: 1.0.0
Author: OSClass Plugins
Author URI: http://osclassplugins.com/
Short Name: auction
Plugin update URI: osclass-auction-plugin
*/
	//todo: change debug to false before releasing.
	define('OB_DEBUG', false);
    require('ModelOffer.php');

 	 function obVersion() {
 	    $pluginInfo = osc_plugin_get_info('auction/index.php');
 	 	 $auction = $pluginInfo['version'];
	     return($auction);
 	 }

 	 //check to see if the osclass_pm plugin is enabled
 	 function osclass_pm_enabled() {
		return osc_plugin_is_enabled('osclass_pm/index.php');
	 }
	 // Checks the version of osclass pm
	 function osclass_pm_version_check(){
			if(osclass_pm_enabled() ) {
				$osc_pm = osc_plugin_get_info('osclass_pm/index.php');
				return $osc_pm['version'];
			} else{
				return 0;
			}
	 }

	 function jsfLoad310() {
		if(osc_is_ad_page() || auction_byItem_page() || view_bids_page() || auction_button_page()) {
	    	osc_enqueue_style('demo-table', osc_base_url() . "oc-content/plugins/auction/css/demo_table.css");
	    	osc_enqueue_style('auction-style', osc_base_url() . "oc-content/plugins/auction/css/style.css");
    	}

		osc_enqueue_script('jquery');
		if(OB_DEBUG == 1) {
			osc_enqueue_script('jquery_migrate', 'jquery');
		}
		osc_enqueue_script('fancybox', 'jquery');
	 }

	function jsAfLoad310() {
		osc_enqueue_style('auction-back-style', osc_base_url() . "oc-content/plugins/auction/css/auction_back.css");
	}

	 // Creates the contact type of email or pm message.
	 // $user is an array
 	 function contact_type($user, $item = null) {
		 if(osc_auction_email() == 2 && osclass_pm_enabled() && $user['pk_i_id'] != '') {
			if(osc_auction_uName() == 1 && osclass_pm_version_check() >= '2.0' ) {
				return '<a title="' . __('Send PM to ','auction') . $user['s_username'] . '" href="' . osc_base_url(true) . '?page=custom&file=osclass_pm/user-send.php&userId=' . $user['pk_i_id'] . '&pm_subject=Re: Offer on ' . $item['s_title'] . '&mType=new"><img src="' . osc_base_url() . 'oc-content/plugins/auction/images/email_compose.png' . '"  width="25px" height="25px" alt="' .__('send PM','auction') . '" /></a>';
			} else {
				return '<a title="' . __('Send PM to ','auction') . $user['r_name'] . '" href="'. osc_base_url(true) . '?page=custom&file=osclass_pm/user-send.php&userId=' . $user['pk_i_id'] . '&pm_subject=Re: Offer on ' . $item['s_title'] . '&mType=new"><img src="' . osc_base_url() . 'oc-content/plugins/auction/images/email_compose.png' . '"  width="25px" height="25px" alt="' . __('send PM','auction') . '" /></a>' ;
			}
		} elseif (osc_auction_email() == 1 || (osc_auction_email() == 2 && $user['pk_i_id'] == '') || (osc_auction_email() == 2 && osclass_pm_enabled() == false) ){
			return '<a title="' . __('Send Email to ','auction') . $user['s_email'] . '" href="mailto:' . $user['s_email'] . '?subject=' . osc_item_title() . '"><img src="' . osc_base_url() . 'oc-content/plugins/auction/images/mail-48.png' . '"  width="25px" height="25px" alt="' . __('send email','auction') . '" /></a>' ;
		} else {
			return '';
		}
	 }

	 function auction_contact($userOffer, $item) {
		 $user = User::newInstance()->findByPrimaryKey($userOffer['seller_id']);
		 if(osc_auction_email() == 2 && osclass_pm_enabled()) {
			return '<a title="' . __('Send a PM to the seller','auction'). '" href="' . osc_base_url(true) . '?page=custom&file=osclass_pm/user-send.php&userId=' . $user['pk_i_id'] . '&pm_subject=Re: Offer on ' . $item['s_title'] . '&mType=new"><img src="' . osc_base_url() . 'oc-content/plugins/auction/images/email_compose.png' . '"  width="25px" height="25px" alt="' . __('send PM','auction') . '" /></a>';
		} elseif (osc_auction_email() == 1 ) {
			return '<a title="' . __('Send Email to seller','auction') . '" href="mailto:' . $user['s_email'] . '"><img src="' . osc_base_url() . 'oc-content/plugins/auction/images/mail-48.png' . '"  width="25px" height="25px" alt="' . __('send email','auction') . '" /></a>';
		} else{
			return '';
		}
	}

    function auction_user_menu() {
        $newOffers = ModelOffer::newInstance()->getOffers('seller_id', osc_logged_user_id(), 'oNew', 1, 1, 'id', 'DESC', NULL);
        ModelOffer::newInstance()->updateOfferNew(osc_logged_user_id());
        $countOffers = count($newOffers);

        echo '<li class="" ><a href="' . osc_render_file_url(osc_plugin_folder(__FILE__) . 'auction_byItem.php') . '" >' . __('View Bids on Your Items', 'auction') . ' (' . $countOffers . ')</a></li>';
        echo '<li class="" ><a href="' . osc_render_file_url(osc_plugin_folder(__FILE__) . 'auction_button.php') . '" >' . __('View Your Submitted Bids', 'auction') . '</a></li>' ;
    }

    function auction_call_after_install() {
		if(OSCLASS_VERSION >= 2.3) {
			$pluginInfo = osc_plugin_get_info('auction/index.php');
			ModelOffer::newInstance()->import('auction/struct.sql');

			osc_set_preference('auction_enabled', '1', 'plugin-auction', 'INTEGER');
			osc_set_preference('auction_lastThree', '0', 'plugin-auction', 'INTEGER');
			//Added in version 2.0
			osc_set_preference('auction_version', $pluginInfo['version'] , 'plugin-auction', 'INTEGER');
			osc_set_preference('auction_locking', '0', 'plugin-auction', 'INTEGER');
			osc_set_preference('auction_email', '1', 'plugin-auction', 'INTEGER');
			osc_set_preference('auction_email_temps', '1', 'plugin-auction', 'INTEGER');
			osc_set_preference('auction_delOff', '0', 'plugin-auction', 'INTEGER');
			osc_set_preference('auction_usersOnly', '1', 'plugin-auction', 'INTEGER');
			osc_set_preference('auction_trade', '0', 'plugin-auction', 'INTEGER');
			osc_set_preference('auction_text', '1', 'plugin-auction', 'INTEGER');
			osc_set_preference('auction_uname', '0', 'plugin-auction', 'INTEGER');
			osc_set_preference('auction_days', '7', 'plugin-auction', 'INTEGER');

			ModelOffer::newInstance()->insertEmailTemplates();
		} else {
			throw new Exception("Bid Button requires Osclass version 2.3 or greater.");
		}
    }

    function auction_call_after_uninstall() {
        ModelOffer::newInstance()->removeEmailTemplates();
        ModelOffer::newInstance()->uninstall();
		osc_delete_preference('auction_enabled', 'plugin-auction');
		osc_delete_preference('auction_lastThree', 'plugin-auction');
		//added in version 2.0
		osc_delete_preference('auction_version', 'plugin-auction');
		osc_delete_preference('auction_locking', 'plugin-auction');
		osc_delete_preference('auction_email', 'plugin-auction');
		osc_delete_preference('auction_email_temps', 'plugin-auction');
		osc_delete_preference('auction_delOff', 'plugin-auction');
		osc_delete_preference('auction_usersOnly', 'plugin-auction');
		osc_delete_preference('auction_trade', 'plugin-auction');
		osc_delete_preference('auction_text', 'plugin-auction');
		osc_delete_preference('auction_uname', 'plugin-auction');
		osc_delete_preference('auction_days', 'plugin-auction');
    }

    function auction_help() {
		osc_admin_render_plugin(osc_plugin_path(dirname(__FILE__)) . '/help.php') ;
    }

function auction_enable_to_list($item_id = '') {
//echo $item_id;
    	?>
    	<style>.share {
}
.span_count {
    font-size: 15px;
    font-weight: bold;
    color: maroon;
    margin-left: 12px;
}

</style><?php
date_default_timezone_set('MTS');
		if(osc_auction_enabled() == 1) {
			$detail = ModelOffer::newInstance()->getOfferItemOption(osc_item_id());
			// checks to see if the seller has accepted an auction
			// if yes then it does not display the auction button.
			$acceptedOffer = ModelOffer::newInstance()->getOffer('item_id', osc_item_id(), 'auction_status', 1, 1, 'id', 'DESC', NULL);
			$newOffers = ModelOffer::newInstance()->getOffers('item_id', osc_item_id(), '', 1, 1, 'id', 'DESC', NULL);
	        ModelOffer::newInstance()->updateOfferNew(osc_logged_user_id());
				
				$days_no = osc_get_preference('auction_days', 'plugin-auction');
				//echo 'ddays no'.$days_no;
				$item_date = osc_item_pub_date();
        		$date = strtotime($item_date);
        		//echo ''; 
				$date = strtotime("+".$days_no." day", $date);
				//echo 'fjdskfjsd'.$date;
				$endDate =  date('Y-m-d H:i:s',$date);
				//echo $endDate;
				$startDate =  date('Y-m-d H:i:s');
				//echo $startDate;
				$days = (strtotime($endDate) - strtotime($startDate)) / (60 * 60 * 24);
//echo $days;
				$left_days = round($days);
        		//echo '<pre>'.print_r($auction,true).'</pre>';
        		//$startDate = $auction['auction_date'];

				//echo osc_format_price($auction['auction_value']);

				if($auction['user_id'] !=''){
        		$user = User::newInstance()->findByPrimaryKey($auction['user_id']);
        		$user['r_name'] = $user['s_name'];
        		$userName = $user['s_name'];
        		if(OSCLASS_VERSION >= '2.3'){
					if(OSCLASS_VERSION >= '3.1' && $user['s_username'] != $user['pk_i_id']){
						$user['s_name'] =  '<a title="'. __("View ","auction"). ucfirst($user['s_username']) . __("'s profile", "auction") . '" href="'. osc_base_url(true) .'?page=user&action=pub_profile&id='. $auction['user_id'] .'" >'. $user['s_username'] . '</a>';
						$userName = '';
					} else {
						$user['s_name'] =  '<a title="'. __("View ","auction"). ucfirst($user['s_name']) . __("'s profile", "auction") . '" href="'. osc_base_url(true) .'?page=user&action=pub_profile&id='. $auction['user_id'] .'" >'. $user['s_name'] . '</a>';
						$userName = '';
					}
        		}
        	} else{
        		$user['s_name'] = $userAuction['b_name'] . ' *';
        		$user['s_email'] = $userAuction['b_email'];
        		$user['pk_i_id'] = '';
        		$userName = $userAuction['b_email'];
        	}

        	//echo $user['r_name'];
        	

	        $countOffers = count($newOffers);

			if(!$acceptedOffer && $left_days > 0) {
				if (osc_is_web_user_logged_in()) {
//echo 'only for login user';
					//if(osc_is_this_category('auction', osc_category_id())) {
						if (@$detail['b_auctionYes'] == 1) {
							?>
							<div class="auction_btn"><strong class="share"><?php _e('Auction Enable', 'auction'); ?></strong><span class="span_count"><?php _e('Bids', 'auction'); ?> : <?php echo $countOffers; ?></span> <span class="span_count"><?php _e('Left Days', 'auction'); ?> : <?php echo $left_days; ?></span>&nbsp; &nbsp;| &nbsp; &nbsp;<a href="<?php echo osc_render_file_url(osc_plugin_folder(__FILE__) . 'view_bids.php&'); ?><?php echo osc_item_id(); ?>"><?php _e('View Bids', 'auction'); ?></a></span></div>
						<?php 
						} // ends if auction button enabled
					//}
				} else if(osc_auction_usersOnly() == 0) {
//echo 'only for Auction user';
					//if(osc_is_this_category('auction', osc_category_id())) {
						if(@$detail['b_auctionYes'] == 1) {
						?>
						<div class="auction_btn"><strong class="share"><?php _e('Auction Enable', 'auction'); ?></strong><span class="span_count"><?php _e('Bids', 'auction'); ?> : <?php echo $countOffers; ?></span> <span class="span_count"><?php _e('Left Days', 'auction'); ?> : <?php echo $left_days; ?></span>&nbsp; &nbsp;| &nbsp; &nbsp;<a href="<?php echo osc_render_file_url(osc_plugin_folder(__FILE__) . 'view_bids.php&'); ?><?php echo osc_item_id(); ?>"><?php _e('View Bids', 'auction'); ?></a></span></div>
						 <?php
						} // ends if auction button enabled
					//}
				} //ends else if statement for users only
				else {

//echo 'For non login user1';echo osc_category_id();
					//if(osc_is_this_category('auction', osc_category_id())) { 
						if(@$detail['b_auctionYes'] == 1) { 
//echo 'For non login user2'; ?>
							<div  class="auction_btn"><strong class="share"><?php _e('Auction Enable', 'auction'); ?></strong><span class="span_count"><?php _e('Bids', 'auction'); ?> : <?php echo $countOffers; ?></span> <span class="span_count"><?php _e('Left Days', 'auction'); ?> : <?php echo $left_days; ?></span>&nbsp; &nbsp;| &nbsp; &nbsp;<a href="<?php echo osc_render_file_url(osc_plugin_folder(__FILE__) . 'view_bids.php&'); ?><?php echo osc_item_id(); ?>"><?php _e('View Bids', 'auction'); ?></a></span></div>
					<?php }
				   //}
				}
			}elseif(@$detail['b_auctionYes'] == 1 && $left_days < 1)
			{ ?>
				<div class="auction_btn"><strong class="share"><?php _e('Auction Closed', 'auction'); ?></strong><span class="span_count"><?php _e('Bids', 'auction'); ?> : <?php echo $countOffers; ?></span> <span class="span_count"><?php _e('Left Days', 'auction'); ?> : <?php echo $left_days; ?></span>&nbsp; &nbsp;| &nbsp; &nbsp;<a href="<?php echo osc_render_file_url(osc_plugin_folder(__FILE__) . 'view_bids.php&'); ?><?php echo osc_item_id(); ?>"><?php _e('View Bids', 'auction'); ?></a></span></div>
			<?php }
			elseif(isset($detail['b_auctionYes']) && $acceptedOffer){ ?> ?>
					<div class="auction_btn"><strong class="share"><?php _e('Bid Accepted', 'auction'); ?></strong><span class="span_count"><?php _e('Bids', 'auction'); ?> : <?php echo $countOffers; ?></span> <span class="span_count"><?php _e('Left Days', 'auction'); ?> : <?php echo $left_days; ?></span>&nbsp; &nbsp;| &nbsp; &nbsp;<a href="<?php echo osc_render_file_url(osc_plugin_folder(__FILE__) . 'view_bids.php&'); ?><?php echo osc_item_id(); ?>"><?php _e('View Bids', 'auction'); ?></a></span></div>
			<?php }
		} //ends if statement for button enabled
    } //ends function

    function auction_button() {
    	?>
    	<style>.share a {
    background-color: #ce3d27;
    background-color: #ce3d27;
    background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #ce3d27),color-stop(100%, #a72915));
    background-image: -webkit-linear-gradient(top, #ce3d27,#a72915);
    background-image: -moz-linear-gradient(top, #ce3d27,#a72915);
    background-image: -ms-linear-gradient(top, #ce3d27,#a72915);
    background-image: -o-linear-gradient(top, #ce3d27,#a72915);
    background-image: linear-gradient(top, #ce3d27,#a72915);
    border: solid 1px #8d2a1b;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    border-bottom-left-radius: 3px;
    border-bottom-right-radius: 3px;
    border-top-left-radius: 3px;
    border-bottom-left-radius: 3px;
    border-top-right-radius: 3px;
    border-bottom-right-radius: 3px;
    display: inline-block;
    vertical-align: middle;
    color: #fff !important;
    line-height: 30px;
    text-decoration: none;
    padding: 0 7px;
    box-shadow: inset 0 1px 0 0 #e9988b;
    text-shadow: 0 1px 0 rgba(255,255,255,0.3);
}
.span_count {
    font-size: 15px;
    font-weight: bold;
    color: maroon;
    margin-left: 12px;
}

@media(max-width : 768px){
.auction_btn {
    clear: both;
    float: none;
    position: relative;
    top: -1px;
    /* clear: both; */
}
}
</style><?php
date_default_timezone_set('MTS');
		if(osc_auction_enabled() == 1) {
			$detail = ModelOffer::newInstance()->getOfferItemOption(osc_item_id());
//print_r($detail);
			// checks to see if the seller has accepted an auction
			// if yes then it does not display the auction button.
			$acceptedOffer = ModelOffer::newInstance()->getOffer('item_id', osc_item_id(), 'auction_status', 1, 1, 'id', 'DESC', NULL);
			$newOffers = ModelOffer::newInstance()->getOffers('item_id', osc_item_id(), '', 1, 1, 'id', 'DESC', NULL);
	        ModelOffer::newInstance()->updateOfferNew(osc_logged_user_id());
				
				$days_no = osc_get_preference('auction_days', 'plugin-auction');
				//echo 'ddays no'.$days_no;
				$item_date = osc_item_pub_date();
        		$date = strtotime($item_date);
        		//echo ''; 
				$date = strtotime("+".$days_no." day", $date);
				//echo 'fjdskfjsd'.$date;
				$endDate =  date('Y-m-d H:i:s',$date);
				//echo $endDate;
				$startDate =  date('Y-m-d H:i:s');
				//echo $startDate;
				$days = (strtotime($endDate) - strtotime($startDate)) / (60 * 60 * 24);
//echo $days;
				$left_days = round($days);
        		//echo '<pre>'.print_r($auction,true).'</pre>';
        		//$startDate = $auction['auction_date'];

				//echo osc_format_price($auction['auction_value']);

				if($auction['user_id'] !=''){
        		$user = User::newInstance()->findByPrimaryKey($auction['user_id']);
        		$user['r_name'] = $user['s_name'];
        		$userName = $user['s_name'];
        		if(OSCLASS_VERSION >= '2.3'){
					if(OSCLASS_VERSION >= '3.1' && $user['s_username'] != $user['pk_i_id']){
						$user['s_name'] =  '<a title="'. __("View ","auction"). ucfirst($user['s_username']) . __("'s profile", "auction") . '" href="'. osc_base_url(true) .'?page=user&action=pub_profile&id='. $auction['user_id'] .'" >'. $user['s_username'] . '</a>';
						$userName = '';
					} else {
						$user['s_name'] =  '<a title="'. __("View ","auction"). ucfirst($user['s_name']) . __("'s profile", "auction") . '" href="'. osc_base_url(true) .'?page=user&action=pub_profile&id='. $auction['user_id'] .'" >'. $user['s_name'] . '</a>';
						$userName = '';
					}
        		}
        	} else{
        		$user['s_name'] = $userAuction['b_name'] . ' *';
        		$user['s_email'] = $userAuction['b_email'];
        		$user['pk_i_id'] = '';
        		$userName = $userAuction['b_email'];
        	}

        	//echo $user['r_name'];
        	

	        $countOffers = count($newOffers);

			if(!$acceptedOffer && $left_days > 0) {
				if (osc_is_web_user_logged_in()) {
					if(osc_is_this_category('auction', osc_category_id())) {
						if (@$detail['b_auctionYes'] == 1) {
							?>
							<div class="auction_btn"><strong class="share"><a id="inline" href='#auction_form' rel='inline'><?php echo osc_auction_text_array(); ?></a></strong><span class="span_count"><?php _e('Bids', 'auction'); ?> : <?php echo $countOffers; ?></span> <span class="span_count"><?php _e('Left Days', 'auction'); ?> : <?php echo $left_days; ?></span>&nbsp; &nbsp;| &nbsp; &nbsp;<a href="<?php echo osc_render_file_url(osc_plugin_folder(__FILE__) . 'view_bids.php&'); ?><?php echo osc_item_id(); ?>"><?php _e('View Bids', 'auction'); ?></a></span></div>
						<?php 
						} // ends if auction button enabled
					}
				} else if(osc_auction_usersOnly() == 0) {
					if(osc_is_this_category('auction', osc_category_id())) {
						if(@$detail['b_auctionYes'] == 1) {
						?>
						<div class="auction_btn"><strong class="share"><a id="inline" href='#auction_form' rel='inline'><?php echo osc_auction_text_array(); ?></a></strong><span class="span_count"><?php _e('Bids', 'auction'); ?> : <?php echo $countOffers; ?></span> <span class="span_count"><?php _e('Left Days', 'auction'); ?> : <?php echo $left_days; ?></span>&nbsp; &nbsp;| &nbsp; &nbsp;<a href="<?php echo osc_render_file_url(osc_plugin_folder(__FILE__) . 'view_bids.php&'); ?><?php echo osc_item_id(); ?>"><?php _e('View Bids', 'auction'); ?></a></span></div>
						 <?php
						} // ends if auction button enabled
					}
				} //ends else if statement for users only
				else {
					if(osc_is_this_category('auction', osc_category_id())) { 
						if(@$detail['b_auctionYes'] == 1) { ?>
							<div  class="auction_btn"><strong class="share"><a id="" href='<?php echo osc_user_login_url() . '?http_referer=' . osc_base_url(true) . '?page=item&id=' . osc_item_id(); ?>'><?php _e('Login to Place Bid', 'auction'); ?></a></strong><span class="span_count"><?php _e('Bids', 'auction'); ?> : <?php echo $countOffers; ?></span> <span class="span_count"><?php _e('Left Days', 'auction'); ?> : <?php echo $left_days; ?></span>&nbsp; &nbsp;| &nbsp; &nbsp;<a href="<?php echo osc_render_file_url(osc_plugin_folder(__FILE__) . 'view_bids.php&'); ?><?php echo osc_item_id(); ?>"><?php _e('View Bids', 'auction'); ?></a></span></div>
					<?php }
				   }
				}
			}elseif(isset($detail['b_auctionYes']) && @$detail['b_auctionYes'] == 1 && $left_days < 1)
			{ ?>
				<div class="auction_btn"><strong class="share"><?php _e('Auction Closed', 'auction'); ?></strong><span class="span_count"><?php _e('Bids', 'auction'); ?> : <?php echo $countOffers; ?></span> <span class="span_count"><?php _e('Left Days', 'auction'); ?> : <?php echo $left_days; ?></span>&nbsp; &nbsp;| &nbsp; &nbsp;<a href="<?php echo osc_render_file_url(osc_plugin_folder(__FILE__) . 'view_bids.php&'); ?><?php echo osc_item_id(); ?>"><?php _e('View Bids', 'auction'); ?></a></span></div>
			<?php }
			elseif(isset($detail['b_auctionYes']) && $acceptedOffer){ ?>
					<div class="auction_btn"><strong class="share"><?php _e('Bid Accepted', 'auction'); ?></strong><span class="span_count"><?php _e('Bids', 'auction'); ?> : <?php echo $countOffers; ?></span> <span class="span_count"><?php _e('Left Days', 'auction'); ?> : <?php echo $left_days; ?></span>&nbsp; &nbsp;| &nbsp; &nbsp;<a href="<?php echo osc_render_file_url(osc_plugin_folder(__FILE__) . 'view_bids.php&'); ?><?php echo osc_item_id(); ?>"><?php _e('View Bids', 'auction'); ?></a></span></div>
			<?php }
		} //ends if statement for button enabled
    } //ends function

    // HELPER
    function osc_auction_enabled() {
        return(osc_get_preference('auction_enabled', 'plugin-auction')) ;
    }
    function osc_auction_lastThree() {
        return(osc_get_preference('auction_lastThree', 'plugin-auction')) ;
    }
    function osc_auction_locking() {
        return(osc_get_preference('auction_locking', 'plugin-auction')) ;
    }
    function osc_auction_email() {
        return(osc_get_preference('auction_email', 'plugin-auction')) ;
    }
    function osc_auction_days() {
    	//osc_set_preference('auction_days', Params::getParam('auction_days'), 'plugin-auction');
        return(osc_get_preference('auction_days', 'plugin-auction')) ;
    }
    function osc_auction_email_temps() {
        return(osc_get_preference('auction_email_temps', 'plugin-auction')) ;
    }
    function osc_auction_delOff() {
        return(osc_get_preference('auction_delOff', 'plugin-auction')) ;
    }
    function osc_auction_usersOnly() {
        return(osc_get_preference('auction_usersOnly', 'plugin-auction')) ;
    }
    function osc_auction_version() {
        return(osc_get_preference('auction_version', 'plugin-auction')) ;
    }
    function osc_auction_trade() {
        return(osc_get_preference('auction_trade', 'plugin-auction')) ;
    }
    function osc_auction_text() {
        return(osc_get_preference('auction_text', 'plugin-auction')) ;
    }
    function osc_auction_uName() {
        return(osc_get_preference('auction_uname', 'plugin-auction')) ;
    }
    function osc_auction_formatPrice($unPrice) {
		$price = str_replace(osc_locale_thousands_sep(), '', trim($unPrice));
		$price = str_replace(osc_locale_dec_point(), '.', $price);
		$fPrice = $price*1000000;
		return $fPrice;
	}
    function osc_auction_text_array() {
        $otext = array();
        $otext = array(2 => __('Place Bid','auction'));
        $buttonText = $otext[osc_auction_text()];
        return $buttonText;
    }

    /**
     * Get if user is on auction button.php page
     *
     * @return boolean
     */
    function auction_button_page() {
		$location = Rewrite::newInstance()->get_location();
		$file     = rtrim(Params::getParam('file'),'?');
		if($location == 'custom' && $file == 'auction/auction_button.php'){
			return TRUE;
		}
		return FALSE;
    }
    /**
     * Get if user is on auction_byItem.php page
     *
     * @return boolean
     */
    function auction_byItem_page() {
		$location = Rewrite::newInstance()->get_location();
		$file     = rtrim(Params::getParam('file'),'?');
		if($location == 'custom' && $file == 'auction/auction_byItem.php'){
			return TRUE;
		}
		return FALSE;
    }

     function view_bids_page() {
		$location = Rewrite::newInstance()->get_location();
		$file     = rtrim(Params::getParam('file'),'?');
		if($location == 'custom' && $file == 'auction/view_bids.php'){
			return TRUE;
		}
		return FALSE;
    }


    function auction_config() {
		osc_admin_render_plugin(osc_plugin_path(dirname(__FILE__)) . '/auction_config.php') ;
    	// Standard configuration page for plugin which extend item's attributes
	    //osc_plugin_configure_view(osc_plugin_path(__FILE__));
    }
	
    // Offer button js
    function auction_js() {
		if(auction_byItem_page()) {
			//fancybox code for the trade popup on the auction_byItem page.
			?>
			<script type="text/javascript">
				( function($) {
					 $(document).ready(function(){
						 $(".trades").fancybox({
							maxWidth	: 800,
							maxHeight	: 600,
							fitToView	: false,
							width		: '500px',
							height		: '450px',
							autoSize	: false,
							closeClick	: false,
							openEffect	: 'none',
							closeEffect	: 'none'
						 });
					 });
				} ) ( jQuery );
			</script>
		<?php }
		if(osc_is_ad_page()) { ?>
			<!-- auction js -->
			<script type="text/javascript">
				( function($) {
					$(document).ready(function(){
						$("#auctionT").attr("disabled", true);

						$("#auctionType").change(function(){
						var auctionType = $(this).val();
						if(auctionType == 1 ){
							$("#auctionT").attr("disabled", true);
						}
						else if(auctionType == 1) {
							$("#auction").removeAttr("disabled");
						}
						else if(auctionType == 2) {
							$("#auction").attr("disabled", true);
							$("#auctionT").attr("disabled", false);
						} else if(auctionType == 3) {
							$("#auctionT").attr("disabled", false);
							$("#auction").attr("disabled", false);
						}
						});
					});
				}) ( jQuery );

				( function($) {
					$(document).ready(function() {
					$("a[rel=inline]").fancybox({
						"overlayOpacity"	:	0.5,
						"overlayColor"		:	"black",
						"overlayShow"		:	true,
						"arrows" 			: false,
						"onClosed" 			:	function() { $("span#auction-message").html("") }
					})
					 });
				} ) ( jQuery );
				
				( function($) {
					$(document).ready(function() {
						 $("#auction_form").bind("submit", function(){
						if ($("#auctionType").val() != 2 ) {
							if ($("#auctionType").val() !=3 ) {
								if ($("#auction").val().length < 1) {
									$("span#auction-message").css({"color":"red"});
											$("span#auction-message").css({"font-size":"20px"} );
											$("span#auction-message").html("<?php _e('Please enter valid amount', 'auction'); ?>");
									$.fancybox.update();
									return false;
								}
							}
						}

					$.fancybox.showLoading();
					$.post(
						"<?php echo osc_ajax_plugin_url('auction/ajax-auction.php'); ?>",
						$("#auction_form").serialize(),
						function(data){
							if (data.success){
							  $("span#auction-message").html(" ");
							  //$("#auction").value="";
							  $.fancybox("<h1 style=\"font-size: 14px;\">" + data.message + "</h1>");
							  $('#auction').val('');
							  $.fancybox.update();
							  location.reload();
							  //document.getElementById("auction").value = "";
							} else {
								$.fancybox.hideLoading();
								$("span#auction-message").css({"color":"red"});
								$("span#auction-message").css({"font-size":"20px"} );
								$("span#auction-message").html(data.message);
								$('#auction').val('');
								//document.getElementById("auction").value = "";
								$.fancybox.update();
							}
						}, "json"
					);
				});
			});
		}) ( jQuery );
	</script>

	<script type="text/javascript">
		( function($) {
			$(document).ready(function() {
				if( $("form[name=item]").length > 0 ) {
				}
			}) ;
		}) ( jQuery );
    </script>
    <!-- end auction js -->

    <!-- start auctionbutton form code -->
    <?php
    // Database connection using the new DAO Model.
    $lastThree = ModelOffer::newInstance()->getOffers('item_id', osc_item_id(), 'auction_status', 2, 1, 'auction_value', 'DESC');
    //$userauctionprice = ModelOffer::newInstance()->getOffers('user_id', osc_logged_user_id(), 'auction_status', 2, 1, 'auction_value', 'DESC');
    //echo 'fkdsjfkdsj';
    //print_r($userauctionprice);
    $auctionTrade = ModelOffer::newInstance()->getOfferItemOption(osc_item_id());

    if(osc_auction_usersOnly() == 1 || osc_is_web_user_logged_in() ){ ?>
		<div style="display:none">
			<form id="auction_form" method="post"  onsubmit="return false;" >
				<input type="hidden" id="user_id" name="user_id" value="<?php echo osc_logged_user_id(); ?>" />
				<input type="hidden" id="seller_id" name="seller_id" value="<?php echo osc_item_user_id(); ?>" />
				<input type="hidden" id="item_id" name="item_id" value="<?php echo osc_item_id(); ?>" />

					<span id="auction-message"></span> 
					<?php //if(osc_auction_lastThree()){ ?>
					<!-- <h3 id="auction-last" style="text-align: center;">
						<?php foreach($lastThree as $a){
							//echo '<pre>'.print_r($a,true).'</pre>';
							echo osc_format_price($a['auction_value']) . '<br />';
						} ?>
					</h3> -->
					<?php //} ?>
					<!--<p><h3><?php _e('Please enter a your Bid','auction'); ?></h3></p>-->
				<p>
				<table class="auctionRows">
						<tr>
							<td><?php echo osc_item_title().' ( '.osc_format_price(osc_item_price()).' ) '; ?></td>
						</tr>
						<tr>
							<!--<td>
							<label for="auction" id="auctionL"><?php _e('Bid','auction'); ?>: </label>
							</td>-->
							<td>
							<input type="text" id="auction" name="auction" size="10"  onkeypress='return isNumberKey(event)' onkeyup='return greaterkey(event)'/><?php echo osc_item_currency();?>
							<h5 id="auction-last" style="text-align: center;">
								<?php 
								if(!empty($lastThree)){
									foreach($lastThree as $a){
										//echo '<pre>'.print_r($a,true).'</pre>';
										$price = osc_format_price($a['auction_value']);
									$shipping_str_rem = preg_replace("/[^0-9,.]/", "", $price);
									$price = $shipping_str_rem + 10;
									?>	
										<?php _e('You have to bid atleast', 'auction'); echo ' '.$price; ?><br />
									<?php	
									}
									}else{
										$price = osc_format_price(osc_item_price());
									$shipping_str_rem = preg_replace("/[^0-9,.]/", "", $price);
									$price = $shipping_str_rem + 10;
									?>	
									<?php _e('You have to bid atleast', 'auction'); echo ' '.$price; ?><br />
									<?php	
									} 
								?>
							</h5>
<?php //echo $price; ?>
<input type="hidden" id="bid_more" name="bid_more" value="<?php echo $price; ?>">
							</td>
						</tr>
					</table>

				</p>
				<br />
				<p>
					<input type="submit" value="<?php _e('Submit Bid','auction'); ?>" />
				</p>
			</form>
			<script>
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57)){
        return false;
    }else{
    	return true;
    }
}

function greaterkey(evt){
 if(evt < "<?php echo osc_format_price($a['auction_value']); ?>") {
        alert('Kit price should be more than <?php echo osc_format_price($a["auction_value"]); ?>');
        return false;
    }
}    

</script>
		</div>

<?php } else if(osc_auction_usersOnly() == 0) { ?>

		<div style="display:none">
			<form id="auction_form" method="post" onsubmit="return false;" >

				<input type="hidden" id="seller_id" name="seller_id" value="<?php echo osc_item_user_id(); ?>" />
				<input type="hidden" id="item_id" name="item_id" value="<?php echo osc_item_id(); ?>" />

					<span id="auction-message"></span>
					<?php if(osc_auction_lastThree()) { ?>
					<h3 id="auction-last" style="text-align: center;">
					<?php _e('Top 3 auctions','auction');?> <br />
						<?php foreach($lastThree as $a){
							echo osc_format_price($a['auction_value']) . '<br />';
						} ?>
					</h3>
					<?php } ?>
					<p><h3><?php _e('Please enter a your auction','auction'); ?></h3></p>
				<p>
				<table class="auctionRows">
					<tr>
						<td>
						<label for="name"><?php _e('Enter your Name','auction'); ?>: </label>
						</td>
						<td>
						<input type="text" id="name" name="name" value=""  />
						</td>
					</tr>
					<tr>
						<td>
						<label for="eMail"><?php _e('Enter your Email Address','auction'); ?>: </label>
						</td>
						<td>
						<input type="text" id="eMail" name="eMail" value="" />
						</td>
					</tr>
					<?php if($auctionTrade['b_auctionTrade'] == 1 && osc_auction_trade() == 1) { ?>
					<tr>
					   <td>
					   <label for="auctionType"><?php _e('Bid Type','auction'); ?></label>
					   </td>
					   <td>
					 <select name="auctionType" id="auctionType">
						 <option value="1"><?php _e('Monetary Offer','auction'); ?></option>
						 <option value="2"><?php _e('Trade Offer','auction'); ?></option>
						 <option value="3"><?php _e('Monetary & Trade Offer','auction'); ?></option>
					 </select>
					   </td>
					</tr>
					<?php } ?>
					<tr>
						<td>
						<label for="auction" id="auctionL"><?php _e('Bid','auction'); ?>: </label>
						</td>
						<td>
						<input type="text" id="auction" name="auction" size="10" /><?php echo osc_item_currency();?>
						</td>
					</tr>
					<?php if($auctionTrade['b_auctionTrade'] == 1 && osc_auction_trade() == 1) { ?>
					<tr>
						<td>
						<label for="auction_text" id="auctiontL"><?php _e('Trade','auction'); ?>: </label>
						</td>
						<td>
						<textarea maxlength="255" name="auction_text" id="auctionT" rows="5"></textarea>
						</td>
					</tr>
					<?php } ?>
				</table>
				</p>
				<p>
					<input type="submit" value="<?php _e('Submit Bid','auction'); ?>" />
				</p>
			</form>
			</div>
			<?php } ?>
			<!-- end auctionbutton form code -->
		<?php
		}
    }

    function auction_status($auctionSt){
    	if ($auctionSt == 1) {
    		return __('Accepted','auction');
    	}
    	elseif($auctionSt == 2) {
    		return __('Pending...','auction');
    	}
    	else {
    		return __('Declined','auction');
    	}
    }

    function auction_form($catId ='') {
		if($catId != '') {
			// We check if the category is the same as our plugin
			if(osc_is_this_category('auction', $catId)) {	
			   if(osc_is_web_user_logged_in()){
?>
<h3 style="margin-top:10px"><?php _e('Go For Auction','auction_button') ; ?></h3>
<table>
<tr>
	<td>
	<input type="checkbox" name="auctionYes" id="auctionYes" value="1" checked /> <label><?php _e('Add Item To Auction','auction_button'); ?></label><br />
	</td>
</tr>
</table>
<?php
				}
			}
		}
    }

    function auction_form_post($item='') { // We receive the Item array thanks to the used Hook!
		if(is_array($item)) {
			// We check if the category is the same as our plugin
			if(osc_is_this_category('auction', $item['fk_i_category_id'])) {
			  // Insert the data in our plugin's table
			  ModelOffer::newInstance()->insertOptions($item['pk_i_id'], (Params::getParam("auctionYes")!='') ? 1 : 0, 0, (Params::getParam("auctionTrade")!='') ? 1 : 0);
			}
		}
    }

    // Self-explanatory
    function auction_item_edit($item='') {
		if($item != '') {
			$catId = Params::getParam('catId');
			// We check if the category is the same as our plugin, wonder if this is actually needed
			if(osc_is_this_category('auction', $catId)) {
				if(osc_is_web_user_logged_in()) {
					require_once 'item_edit.php';
				}
			}
		}
    }

    function auction_item_edit_post($item='') {
		if(is_array($item)) {
			// We check if the category is the same as our plugin
			if(osc_is_this_category('auction', $item['fk_i_category_id'])) {
				// Insert the data in our plugin's table
				ModelOffer::newInstance()->replaceOptions($item['pk_i_id'], (Params::getParam("auctionYes")!='') ? 1 : 0, 0, (Params::getParam("auctionTrade")!='') ? 1 : 0);
			}
		}
	}

    function auction_item_delete($id) {
    	ModelOffer::newInstance()->deleteOfferItem($id);
    }

    /**
     * Add new options to supertoolbar plugin (if installed)
     */
    function auction_supertoolbar() {

        if( !osc_is_web_user_logged_in() ) {
            return false;
        }

        if( Rewrite::newInstance()->get_location() != 'item' ) {
            return false;
        }

        //if( osc_item_user_id() != osc_logged_user_id() ) {
          //  return false;
        //}

        $toolbar = SuperToolBar::newInstance();
        $auctionCheck = ModelOffer::newInstance()->getOffer('seller_id', osc_logged_user_id(), 'item_id', osc_item_id() );

        if($auctionCheck) {
			$auction_url = osc_base_url(true).'?page=custom&file=auction/auction_byItem.php#item' . osc_item_id();
			$toolbar->addOption('<a href="' . $auction_url . '" />' . __('View auctions on this ad', 'offfer_button') . '</a>');
        }

        $auctionStatus = ModelOffer::newInstance()->getOffer('user_id', osc_logged_user_id(), 'item_id', osc_item_id() );

        if($auctionStatus) {
			$auction_url = osc_base_url(true).'?page=custom&file=auction/auction_button.php#item' . osc_item_id();
			$toolbar->addOption('<a href="' . $auction_url . '" />' . __('View status of auction', 'offfer_button') . '</a>');
        }
    }

    /**
     * Send email to users with auctions and statuses
     *
     * @param integer $item
     * @param integer $auction_value
     *
     * @dynamic tags
     *
     * '{ITEM_ID}', '{CONTACT_NAME}', '{CONTACT_EMAIL}', '{WEB_URL}', '{ITEM_TITLE}',
     * '{ITEM_URL}', '{WEB_TITLE}', '{OFFER_URL}', '{OFFER_VALUE}
     */

    function auction_button_send_email($item, $auction_value) {

        $mPages = new Page() ;
        $aPage = $mPages->findByInternalName('email_new_auction') ;
        $locale = osc_current_user_locale() ;
        $content = array();
        if(isset($aPage['locale'][$locale]['s_title'])) {
            $content = $aPage['locale'][$locale];
        } else {
            $content = current($aPage['locale']);
        }

		$item_url    = osc_item_url( ) ;
        $item_url    = '<a href="' . $item_url . '" >' . $item_url . '</a>';

        $auction_url    = osc_base_url(true) . '?page=custom&file=auction/auction_byItem.php#item' . $item['pk_i_id'] ;
        $auction_url    = '<a href="' . $auction_url . '" >' . $auction_url . '</a>';

        $words   = array();
        $words[] = array('{ITEM_ID}', '{CONTACT_NAME}', '{CONTACT_EMAIL}', '{WEB_URL}', '{ITEM_TITLE}',
            '{ITEM_URL}', '{WEB_TITLE}', '{OFFER_URL}', '{OFFER_VALUE}');
        $words[] = array($item['pk_i_id'], $item['s_contact_name'], $item['s_contact_email'], osc_base_url(), $item['s_title'], $item_url, osc_page_title(), $auction_url, osc_format_price($auction_value)) ;

        $title = osc_mailBeauty($content['s_title'], $words) ;
        $body  = osc_mailBeauty($content['s_text'], $words) ;

        $emailParams =  array('subject'  => $title
                             ,'to'       => $item['s_contact_email']
                             ,'to_name'  => $item['s_contact_name']
                             ,'body'     => $body
                             ,'alt_body' => $body);

        osc_sendMail($emailParams);
    }
 /**
     * Send email to users with auctions and statuses
     *
     * @param integer $item
     * @param integer $auction_value
     *
     * @dynamic tags
     *
     * '{ITEM_ID}', '{CONTACT_NAME}', '{CONTACT_EMAIL}', '{WEB_URL}', '{ITEM_TITLE}',
     * '{ITEM_URL}', '{WEB_TITLE}', '{OFFER_URL}', '{OFFER_VALUE}
     */

    function auction_button_send_update_email($item, $auction_value, $to_email, $to_name) 
    {

		$item_url    = osc_item_url( ) ;
        $item_url    = '<a href="' . $item_url . '" >' . $item_url . '</a>';

        $auction_url    = osc_base_url(true) . '?page=custom&file=auction/auction_byItem.php#item' . $item['pk_i_id'] ;
        $auction_url    = '<a href="' . $auction_url . '" >' . $auction_url . '</a>';

        $message = "Hi ".$to_email.'!<br/>';
        $message .= $item['s_title']." just got a new auction of ". osc_format_price($auction_value) ." on ". osc_page_title().'<br/>';
        $message .= "Click on the link to view the new auction ".$auction_url.'<br/>';
        $message .= "This is an automatic email, if you have already seen this auction, please ignore this email.<br/>";
        $message .= "Thanks<br/>";

        $emailParams =  array('subject'  => "Bid Updates"
                             ,'to'       => $to_email
                             ,'to_name'  => $to_name
                             ,'body'     => $message
                             ,'alt_body' => $message);

        osc_sendMail($emailParams);
    }
    /**
     * Send email to user with auctions and statuses
     *
     * @param integer $item, $auction_status
     * @param string  $senderName, $senderEmail
     *
     * @dynamic tags
     *
     * '{ITEM_ID}', '{CONTACT_NAME}', '{CONTACT_EMAIL}', '{WEB_URL}', '{ITEM_TITLE}',
     * '{ITEM_URL}', '{WEB_TITLE}', '{SELLER_EMAIL}', '{OFFER_STATUS}', '{OFFER_STATUS_URL}', '{SELLER_PHONE}'
     */

	function auction_button_send_status_email($item, $auction_status, $senderName, $senderEmail) {

        $mPages = new Page() ;
        $aPage = $mPages->findByInternalName('email_auction_status') ;
        $locale = osc_current_user_locale() ;
        $content = array();
        if(isset($aPage['locale'][$locale]['s_title'])) {
            $content = $aPage['locale'][$locale];
        } else {
            $content = current($aPage['locale']);
        }

        $user = User::newInstance()->findByPrimaryKey($item['fk_i_user_id']);
        $itemEmail = $item['s_contact_email'];

        if($user['s_phone_land'] != '' || $user['s_phone_mobile'] !='') {
			if($user['s_phone_land'] != '') {
				$userPhone = $user['s_phone_land'];
			} else{
				$userPhone = $user['s_phone_mobile'];
			}
        } else {
           $userPhone = '';
        }

        if($senderEmail != '') {
        	$item['s_contact_email'] = $senderEmail;
        	$item['s_contact_name'] = $senderName;
        }
        $sendEmail = $item['s_contact_email'];
        $sendName = $item['s_contact_name'];
		$item_url    = osc_item_url( );
        $item_url    = '<a href="' . $item_url . '" >' . $item_url . '</a>';
        $auction_status_url    = osc_base_url(true) . '?page=custom&file=auction/auction_button.php#item' . $item['pk_i_id'];
        $auction_status_url    = '<a href="' . $auction_status_url . '" >' . $auction_status_url . '</a>';
		$status_auction = array();
        $status_auction = array('1' => __('has been accepted', 'auction'), '2' => __('has been changed to pending','auction'), '3' => __('has been declined','auction'));

		if ( $auction_status == 1 ) {
			$sEmail = $itemEmail;
		} else {
			$sEmail = '';
		}

        $words   = array();
        $words[] = array('{ITEM_ID}', '{CONTACT_NAME}', '{CONTACT_EMAIL}', '{WEB_URL}', '{ITEM_TITLE}',
            '{ITEM_URL}', '{WEB_TITLE}', '{SELLER_EMAIL}', '{OFFER_STATUS}', '{OFFER_STATUS_URL}', '{SELLER_PHONE}');
        $words[] = array($item['pk_i_id'], $item['s_contact_name'], $item['s_contact_email'], osc_base_url(), $item['s_title'],
            $item_url, osc_page_title(), $sEmail, $status_auction[$auction_status], $auction_status_url, $userPhone);

        $title = osc_mailBeauty($content['s_title'], $words);
        $body  = osc_mailBeauty($content['s_text'], $words);

		$emailParams =  array('subject'  => $title
                             ,'to'       => $sendEmail
                             ,'to_name'  => $sendName
                             ,'body'     => $body
                             ,'alt_body' => $body);
							 
        osc_sendMail($emailParams);
    }

    function auction_title_filter($text) {
		$location = Rewrite::newInstance()->get_location();
		$oscFile = Params::getParam('file');

		if($location == 'custom' && $oscFile == 'auction/auction_byItem.php') {
			$text = __('Bids on Your Listings', 'auction') . ' - ' . osc_page_title();
			return $text;
		} else if($location == 'custom' && $oscFile == 'auction/auction_button.php') {
			$text = __('Your Submitted Bids', 'auction') . ' - ' . osc_page_title();
			return $text;
		}
	}

	function obTitle($title) {
		$file = explode('/', Params::getParam('file'));
	        $title = 'Plugin - Auction';
	        if($file[1] == 'auction_config.php') { ?>
				<a class="btn ico ico-32 ico-help float-right" href="#"></a>
				<script>
					$(document).ready(function(){
						$("#help-box").append("<h3><?php _e('Bid Button Help','auction'); ?></h3>");
						$("#help-box").append("<p><a href='<?php echo osc_admin_render_plugin_url(osc_plugin_folder(__FILE__) . 'help.php'); ?>'><?php _e('Click here for help','auction'); ?>.</a></p>");
					});
				</script>
			<?php }
		return $title;
	 }

    // This is needed in order to be able to activate the plugin
    osc_register_plugin(osc_plugin_path(__FILE__), 'auction_call_after_install') ;
    // This is a hack to show a Uninstall link at plugins table (you could also use some other hook to show a custom option panel)
    osc_add_hook(osc_plugin_path(__FILE__) . '_uninstall', 'auction_call_after_uninstall') ;
    // This is a hack to show a Configure link at plugins table (you could also use some other hook to show a custom option panel)
    osc_add_hook(osc_plugin_path(__FILE__) . '_configure', 'auction_config') ;
	
	$oscFile = Params::getParam('file');
	$obFile = explode('/', $oscFile);
	if ($obFile[0] == 'auction') {
		osc_add_filter('meta_title_filter', 'auction_title_filter');
	}

    // Add hook for item deleted
    osc_add_hook('delete_item', 'auction_item_delete');

    if(osc_auction_enabled() == 1) {
		// Add link in user menu page
		osc_add_hook('user_menu', 'auction_user_menu') ;
    }

    if(osc_auction_enabled() == 1) {
		// add javascript
		osc_add_hook('header', 'auction_js', 10) ;
		osc_add_hook('before_html', 'jsfLoad310');
		osc_add_hook('init_admin', 'jsAfLoad310');
		osc_add_hook('admin_header', 'osclass_ob_admin_header');

		// When publishing an item we show an extra form with more attributes
		osc_add_hook('item_form', 'auction_form');
		// To add that new information to our custom table
		osc_add_hook('posted_item', 'auction_form_post');
		// Edit an item special attributes
		osc_add_hook('item_edit', 'auction_item_edit');
		// Edit an item special attributes POST
		osc_add_hook('edited_item', 'auction_item_edit_post');
		// Add hook to supertoolbar
		osc_add_hook('supertoolbar_hook', 'auction_supertoolbar');
    }
?>