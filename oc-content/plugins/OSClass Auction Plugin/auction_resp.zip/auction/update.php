<?php
$override = Params::getParam('force');
/*update section */
if ((osc_get_preference('auction_version', 'plugin-auction') == '' ) || (obVersion() > osc_auction_version() ) || ($override == 1)){
  	update(osc_auction_version(), $override);
}else {
  	echo '<div style="text-align:center; font-size:22px; background-color:#00bb00;"><p>' . __('The Offer Button is up to date', 'auction') . '.</p></div>';
  	osc_add_flash_info_message( __('The Offer Button is up to date','auction'), 'admin' ) ;
  	// REDIRECT
	header("Location: " . osc_admin_render_plugin_url('auction/auction_config.php') );
}

function update($version, $override) {
	if($version == '') {$version = 0;}
	if($version < '2.0' || $override == 1){

		if($version < '2.0') {
			ModelOffer::newInstance()->import('auction/update.sql');

			$auctionPrice = '';
			$auctions = ModelOffer::newInstance()->getOffers(null, null, null,null,null,null,null,null);
			foreach ($auctions as $auction) {
				$price = str_replace(osc_locale_thousands_sep(), '', trim($auction['auction_value']));
				$price = str_replace(osc_locale_dec_point(), '.', $price);
				$auctionPrice = $price*1000000;
				ModelOffer::newInstance()->updateOfferPrice($auctionPrice, $auction['id']);
			}
		}

		osc_set_preference('auction_version', '2.0', 'plugin-auction', 'INTEGER');

		osc_set_preference('auction_locking', '0', 'plugin-auction', 'INTEGER');
		osc_set_preference('auction_email', '1', 'plugin-auction', 'INTEGER');
		osc_set_preference('auction_email_temps', '1', 'plugin-auction', 'INTEGER');
		osc_set_preference('auction_delOff', '0', 'plugin-auction', 'INTEGER');
		osc_set_preference('auction_usersOnly', '1', 'plugin-auction', 'INTEGER');
		osc_set_preference('auction_trade', '0', 'plugin-auction', 'INTEGER');
		osc_set_preference('auction_text', '1', 'plugin-auction', 'INTEGER');
		osc_set_preference('auction_uname', '0', 'plugin-auction', 'INTEGER');

		osc_reset_preferences();
   }

   if($version < '2.0.41' || $override == 1) {
		osc_set_preference('auction_version', '2.0.41', 'plugin-auction', 'INTEGER');
		osc_reset_preferences();
   }

	//echo '<div style="text-align:center; font-size:22px; background-color:#00bb00;"><p>' . __('Offer Button Updated to version', 'auction') . ' ' . osc_auction_version() . '.</p></div>' ;
	osc_add_flash_ok_message( __('Offer Button Updated to version','auction') . ' ' . osc_auction_version(), 'admin' ) ;
	// REDIRECT
	header("Location: " . osc_admin_render_plugin_url('auction/auction_config.php') );
}
?>