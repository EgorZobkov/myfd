<h3 style="margin-top:10px"><?php _e('Go For Auction','auction_button') ; ?></h3>
<table>
<tr>
	<td>
	<input type="checkbox" name="auctionYes" id="auctionYes" value="1" checked /> <label><?php _e('Add Item To Auction','auction_button'); ?></label><br />
	</td>
</tr>
</table>