ALTER TABLE /*TABLE_PREFIX*/t_auction_button ADD user_locked INT(2) DEFAULT "0" AFTER auction_status;
ALTER TABLE /*TABLE_PREFIX*/t_auction_button ADD b_name VARCHAR(50) AFTER user_id;
ALTER TABLE /*TABLE_PREFIX*/t_auction_button ADD b_email VARCHAR(50) AFTER b_name;
ALTER TABLE /*TABLE_PREFIX*/t_auction_button ADD sDelete INT(2) DEFAULT "0" AFTER auction_date;
ALTER TABLE /*TABLE_PREFIX*/t_auction_button ADD auction_type INT(2) DEFAULT "1" AFTER user_locked;
ALTER TABLE /*TABLE_PREFIX*/t_auction_button ADD oNew int (1) AFTER sDelete;
ALTER TABLE /*TABLE_PREFIX*/t_auction_button ADD trade_text VARCHAR(255) AFTER auction_type;

ALTER TABLE /*TABLE_PREFIX*/t_auction_item_options ADD b_auctionMonetary BOOLEAN AFTER b_auctionYes;
ALTER TABLE /*TABLE_PREFIX*/t_auction_item_options ADD b_auctionTrade BOOLEAN AFTER b_auctionMonetary;



CREATE TABLE IF NOT EXISTS /*TABLE_PREFIX*/t_auction_user_locked(
    id int(10) unsigned NOT NULL AUTO_INCREMENT,
	 seller_id int(11),
	 user_id int(11),
	 email varchar (50),
	 reason_code int(11),
	 locked int(1),

        PRIMARY KEY (id)

) ENGINE=InnoDB DEFAULT CHARACTER SET 'UTF8' COLLATE 'UTF8_GENERAL_CI';
