<?php
$itemid = Params::getParam('itemId');
$detail = ModelOffer::newInstance()->getOfferItemOption($itemid);
if($detail ["b_auctionYes"] == 1 ) {
	$ch1='checked';
} else {
	$ch1='unchecked';
}
?>
<h3 class="auctionPostOptions"><?php _e('Auction List','auction_button') ; ?></h3>
<table>
<tr>
	<td>
		<label for="auctionYes" class="auctionYes"><?php echo __('Add Item To Auction','auction'); ?></label>
		<input type="checkbox" name="auctionYes" id="auctionYes" value="1" <?php print $ch1; ?> >
	</td>
</tr>
</table>